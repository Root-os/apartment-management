// All components mapping with path for internal routes

import { lazy } from 'react'

const Dashboard = lazy(() => import('../pages/protected/Dashboard'))
const Welcome = lazy(() => import('../pages/protected/Welcome'))
const Page404 = lazy(() => import('../pages/protected/404'))
const Blank = lazy(() => import('../pages/protected/Blank'))
const Charts = lazy(() => import('../pages/protected/Charts'))
const Leads = lazy(() => import('../pages/protected/Leads'))
const Integration = lazy(() => import('../pages/protected/Integration'))
const Calendar = lazy(() => import('../pages/protected/Calendar'))
const Team = lazy(() => import('../pages/protected/Team'))
const Transactions = lazy(() => import('../pages/protected/Transactions'))
const Bills = lazy(() => import('../pages/protected/Bills'))
const ProfileSettings = lazy(() => import('../pages/protected/ProfileSettings'))
const GettingStarted = lazy(() => import('../pages/GettingStarted'))
const DocFeatures = lazy(() => import('../pages/DocFeatures'))
const DocComponents = lazy(() => import('../pages/DocComponents'))
const SliderView = lazy(() => import('../pages/protected/SliderView'))
const SliderAdd = lazy(() => import('../pages/protected/SliderAdd'))
const CategoryView = lazy(() => import('../pages/protected/CategoryView'))
const CategoryAdd = lazy(() => import('../pages/protected/CategoryAdd'))
const BlogsAdd = lazy(() => import('../pages/protected/BlogsAdd'))
const BlogsView = lazy(() => import('../pages/protected/BlogsView'))
const ServiceAdd = lazy(() => import('../pages/protected/ServiceAdd'))
const ServiceView = lazy(() => import('../pages/protected/ServiceView'))
const FaqAdd = lazy(() => import('../pages/protected/FaqAdd'))
const FaqView = lazy(() => import('../pages/protected/FaqView'))
const ApartmentAdd = lazy(() => import('../pages/protected/ApartmentAdd'))
const ApartmentView = lazy(() => import('../pages/protected/ApartmentView'))
const BookingAdd = lazy(() => import('../pages/protected/BookingAdd'))
const BookedView = lazy(() => import('../pages/protected/BookedView'))
const GalleryAdd = lazy(() => import('../pages/protected/GalleryAdd'))
const GalleryView = lazy(() => import('../pages/protected/GalleryView'))
const AboutUs = lazy(() => import('../pages/protected/AboutUs'))
const ContactUs = lazy(() => import('../pages/protected/ContactUs'))
const PartnerAdd = lazy(() => import('../pages/protected/PartnerAdd'))
const PartnerView = lazy(() => import('../pages/protected/PartnerView'))
const Users = lazy(() => import('../pages/protected/Users'))
const TestimonyAdd = lazy(() => import('../pages/protected/TestimonyAdd'))
const TestimonyView = lazy(() => import('../pages/protected/TestimonyView'))
const ResourceView = lazy(() => import('../pages/protected/ResourceView'))
const ResourceAdd = lazy(() => import('../pages/protected/ResourceAdd'))

const routes = [
  {
    path: '/', // the url
    component: Dashboard, // view rendered
  },
  {
    path: '/welcome', // the url
    component: Welcome, // view rendered
  },
  {
    path: '/leads',
    component: Leads,
  },
  {
    path: '/settings-team',
    component: Team,
  },
  {
    path: '/calendar',
    component: Calendar,
  },
  {
    path: '/transactions',
    component: Transactions,
  },
  {
    path: '/settings-profile',
    component: ProfileSettings,
  },
  {
    path: '/settings-billing',
    component: Bills,
  },
  {
    path: '/getting-started',
    component: GettingStarted,
  },
  {
    path: '/features',
    component: DocFeatures,
  },
  {
    path: '/components',
    component: DocComponents,
  },
  {
    path: '/integration',
    component: Integration,
  },
  {
    path: '/charts',
    component: Charts,
  },
  {
    path: '/404',
    component: Page404,
  },
  {
    path: '/blank',
    component: Blank,
  },
  {
    path: '/slider-add', // the url
    component: SliderAdd, // view rendered
  },
  {
    path: '/slider-view', // the url
    component: SliderView, // view rendered
  },
  {
    path: '/category-view', // the url
    component: CategoryView, // view rendered
  },
  {
    path: '/category-add', // the url
    component: CategoryAdd, // view rendered
  },
  {
    path: '/blogs-add', 
    component: BlogsAdd, 
  },
  {
    path: '/blogs-view', 
    component: BlogsView, 
  },
  {
    path: '/services-add', 
    component: ServiceAdd, 
  },
  {
    path: '/services-view', 
    component: ServiceView, 
  },
  {
    path: '/faq-add', 
    component: FaqAdd, 
  },
  {
    path: '/faq-view', 
    component: FaqView, 
  },
  {
    path: '/apartment-add', 
    component: ApartmentAdd, 
  },
  {
    path: '/apartment-view', 
    component: ApartmentView, 
  },
  {
    path: '/bookApartment-add', 
    component: BookingAdd, 
  },
  {
    path: '/bookApartment-view', 
    component: BookedView, 
  },
  {
  path: '/gallery-add', 
    component: GalleryAdd, 
  },
  {
  path: '/gallery-view', 
  component: GalleryView, 
  },
  {
    path: '/aboutUs-view', 
    component: AboutUs, 
  },
  {
    path: '/contact-view', 
    component: ContactUs, 
  },
  {
    path: '/partner-add', 
    component: PartnerAdd, 
  },
  {
    path: '/partner-view', 
    component: PartnerView, 
  },
  {
    path: '/users-view', 
    component: Users, 
  },
  {
    path: '/testimony-add', 
    component: TestimonyAdd, 
  },
  {
    path: '/testimony-view', 
    component: TestimonyView, 
  },
  {
    path: '/resource-view', 
    component: ResourceView, 
  },
  {
    path: '/resource-add', 
    component: ResourceAdd, 
  },
]

export default routes
