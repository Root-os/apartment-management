/** Icons are imported separatly to reduce build time */
import BellIcon from '@heroicons/react/24/outline/BellIcon'
import DocumentTextIcon from '@heroicons/react/24/outline/DocumentTextIcon'
import Squares2X2Icon from '@heroicons/react/24/outline/Squares2X2Icon'
import TableCellsIcon from '@heroicons/react/24/outline/TableCellsIcon'
import WalletIcon from '@heroicons/react/24/outline/WalletIcon'
import CodeBracketSquareIcon from '@heroicons/react/24/outline/CodeBracketSquareIcon'
import DocumentIcon from '@heroicons/react/24/outline/DocumentIcon'
import ExclamationTriangleIcon from '@heroicons/react/24/outline/ExclamationTriangleIcon'
import CalendarDaysIcon from '@heroicons/react/24/outline/CalendarDaysIcon'
import ArrowRightOnRectangleIcon from '@heroicons/react/24/outline/ArrowRightOnRectangleIcon'
import UserIcon from '@heroicons/react/24/outline/UserIcon'
import Cog6ToothIcon from '@heroicons/react/24/outline/Cog6ToothIcon'
import BoltIcon from '@heroicons/react/24/outline/BoltIcon'
import ChartBarIcon from '@heroicons/react/24/outline/ChartBarIcon'
import CurrencyDollarIcon from '@heroicons/react/24/outline/CurrencyDollarIcon'
import InboxArrowDownIcon from '@heroicons/react/24/outline/InboxArrowDownIcon'
import UsersIcon from '@heroicons/react/24/outline/UsersIcon'
import KeyIcon from '@heroicons/react/24/outline/KeyIcon'
import DocumentDuplicateIcon from '@heroicons/react/24/outline/DocumentDuplicateIcon'
import FlagIcon from '@heroicons/react/24/outline/FlagIcon'
import TagIcon from '@heroicons/react/24/outline/TagIcon'
import BookOpenIcon from '@heroicons/react/24/outline/BookOpenIcon'
import QuestionMarkCircleIcon from '@heroicons/react/24/outline/QuestionMarkCircleIcon'
import CalendarIcon from '@heroicons/react/24/outline/CalendarIcon'
import HomeIcon from '@heroicons/react/24/outline/HomeIcon'
import ServerIcon from '@heroicons/react/24/outline/ServerIcon'
import ClipboardDocumentListIcon from '@heroicons/react/24/outline/ClipboardDocumentListIcon'
import PhoneIcon from '@heroicons/react/24/outline/PhoneIcon'
import BriefcaseIcon from '@heroicons/react/24/outline/BriefcaseIcon'
import GlobeAltIcon from '@heroicons/react/24/outline/GlobeAltIcon'
import FilmIcon from '@heroicons/react/24/outline/FilmIcon'


import PlusIcon from '@heroicons/react/24/outline/PlusIcon'
import EyeIcon from '@heroicons/react/24/outline/EyeIcon'




const iconClasses = `h-6 w-6`
const submenuIconClasses = `h-5 w-5`

const routes = [

  {
    path: '/app/dashboard',
    icon: <Squares2X2Icon className={iconClasses}/>, 
    name: 'Dashboard',
  },

  // {
  //   path: '/app/leads', 
  //   icon: <InboxArrowDownIcon className={iconClasses}/>, 
  //   name: 'Leads', 
  // },
  // {
  //   path: '/app/transactions',
  //   icon: <CurrencyDollarIcon className={iconClasses}/>, 
  //   name: 'Transactions', 
  // },
  // {
  //   path: '/app/charts',
  //   icon: <ChartBarIcon className={iconClasses}/>, 
  //   name: 'Analytics', 
  // },
  // {
  //   path: '/app/integration',
  //   icon: <BoltIcon className={iconClasses}/>, 
  //   name: 'Integration', 
  // },
  // {
  //   path: '/app/calendar', 
  //   icon: <CalendarDaysIcon className={iconClasses}/>,
  //   name: 'Calendar', 
  // },

  // {
  //   path: '', 
  //   icon: <DocumentDuplicateIcon className={`${iconClasses} inline` }/>, 
  //   name: 'Pages', 
  //   submenu : [
  //     {
  //       path: '/login',
  //       icon: <ArrowRightOnRectangleIcon className={submenuIconClasses}/>,
  //       name: 'Login',
  //     },
  //     {
  //       path: '/register', 
  //       icon: <UserIcon className={submenuIconClasses}/>, 
  //       name: 'Register',
  //     },
  //     {
  //       path: '/forgot-password',
  //       icon: <KeyIcon className={submenuIconClasses}/>,
  //       name: 'Forgot Password',
  //     },
  //     {
  //       path: '/app/blank',
  //       icon: <DocumentIcon className={submenuIconClasses}/>,
  //       name: 'Blank Page',
  //     },
  //     {
  //       path: '/app/404',
  //       icon: <ExclamationTriangleIcon className={submenuIconClasses}/>,
  //       name: '404',
  //     },
  //   ]
  // },
  // {
  //   path: '', 
  //   icon: <Cog6ToothIcon className={`${iconClasses} inline` }/>,
  //   name: 'Settings', 
  //   submenu : [
  //     {
  //       path: '/app/settings-profile', 
  //       icon: <UserIcon className={submenuIconClasses}/>,
  //       name: 'Profile', 
  //     },
  //     {
  //       path: '/app/settings-billing',
  //       icon: <WalletIcon className={submenuIconClasses}/>,
  //       name: 'Billing',
  //     },
  //     {
  //       path: '/app/settings-team', 
  //       icon: <UsersIcon className={submenuIconClasses}/>, 
  //       name: 'Team Members',
  //     },
  //   ]
  // },
  // {
  //   path: '',
  //   icon: <DocumentTextIcon className={`${iconClasses} inline` }/>, 
  //   name: 'Documentation', 
  //   submenu : [
  //     {
  //       path: '/app/getting-started',
  //       icon: <DocumentTextIcon className={submenuIconClasses}/>, 
  //       name: 'Getting Started', 
  //     },
  //     {
  //       path: '/app/features',
  //       icon: <TableCellsIcon className={submenuIconClasses}/>, 
  //       name: 'Features',
  //     },
  //     {
  //       path: '/app/test',
  //       icon: <TableCellsIcon className={submenuIconClasses}/>, 
  //       name: 'test',
  //     },
  //     {
  //       path: '/app/components',
  //       icon: <CodeBracketSquareIcon className={submenuIconClasses}/>, 
  //       name: 'Components',
  //     }
  //   ]
  // },
  {
    path: '', 
    icon: <FlagIcon className={`${iconClasses} inline` }/>,
    name: 'Slider', 
    submenu : [
      {
        path: '/app/slider-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Slider', 
      },
      {
        path: '/app/slider-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View Slider',
      },

    ]
  },
  {
    path: '', //no url needed as this has submenu
    icon: <TagIcon className={`${iconClasses} inline` }/>, // icon component
    name: 'Category', // name that appear in Sidebar
    submenu : [
      {
        path: '/app/category-add', //url
        icon: <PlusIcon className={submenuIconClasses}/>, // icon component
        name: 'Add Category', // name that appear in Sidebar
      },
      {
        path: '/app/category-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Category List',
      },

    ]
  },
  {
    path: '', //no url needed as this has submenu
    icon: <BookOpenIcon className={`${iconClasses} inline` }/>, // icon component
    name: 'Blog', // name that appear in Sidebar
    submenu : [
      {
        path: '/app/blogs-add', //url
        icon: <PlusIcon className={submenuIconClasses}/>, // icon component
        name: 'Add Blog', // name that appear in Sidebar
      },
      {
        path: '/app/blogs-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View Blogs',
      },

    ]
  },
  {
    path: '', 
    icon: <ServerIcon className={`${iconClasses} inline` }/>, 
    name: 'Service', 
    submenu : [
      {
        path: '/app/services-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Service', 
      },
      {
        path: '/app/services-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Service Lists',
      },

    ]
  },
  {
    path: '', 
    icon: <HomeIcon className={`${iconClasses} inline` }/>, 
    name: 'Apartment', 
    submenu : [
      {
        path: '/app/apartment-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Apartment', 
      },
      {
        path: '/app/apartment-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View Apartments',
      },

    ]
  },
  {
    path: '', //no url needed as this has submenu
    icon: <CalendarIcon className={`${iconClasses} inline` }/>, // icon component
    name: 'Book Apartment', // name that appear in Sidebar
    submenu : [
      {
        path: '/app/bookApartment-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Booked Lists',
      },

    ]
  },
  {
    path: '', //no url needed as this has submenu
    icon: <ClipboardDocumentListIcon className={`${iconClasses} inline` }/>, // icon component
    name: 'Review', // name that appear in Sidebar
    submenu : [
      {
        path: '/app/',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View Reviews',
      },

    ]
  },
  {
    path: '', 
    icon: <QuestionMarkCircleIcon className={`${iconClasses} inline` }/>, 
    name: 'FAQ', 
    submenu : [
      {
        path: '/app/faq-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add QA', 
      },
      {
        path: '/app/faq-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'FAQs',
      },

    ]
  },
  {
    path: '', 
    icon: <FilmIcon className={`${iconClasses} inline` }/>, 
    name: 'Gallery', 
    submenu : [
      {
        path: '/app/gallery-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Gallery', 
      },
      {
        path: '/app/gallery-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View Gallery',
      },

    ]
  },
  {
    path: '', 
    icon: <GlobeAltIcon className={`${iconClasses} inline` }/>, 
    name: 'Partner', 
    submenu : [
      {
        path: '/app/partner-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Partner', 
      },
      {
        path: '/app/partner-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Partner List',
      },

    ]
  },
  {
    path: '', 
    icon: <GlobeAltIcon className={`${iconClasses} inline` }/>, 
    name: 'Testimony', 
    submenu : [
      {
        path: '/app/testimony-add', 
        icon: <PlusIcon className={submenuIconClasses}/>, 
        name: 'Add Testimony', 
      },
      {
        path: '/app/testimony-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Testimonials',
      },

    ]
  },
  {
    path: '', 
    icon: <UserIcon className={`${iconClasses} inline` }/>, 
    name: 'User', 
    submenu : [
    
      {
        path: '/app/users-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'User List',
      },

    ]
  },
  {
    path: '', 
    icon: <BriefcaseIcon className={`${iconClasses} inline` }/>, 
    name: 'About Us', 
    submenu : [
      {
        path: '/app/aboutUs-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'View ',
      },

    ]
  },
  {
    path: '', 
    icon: <PhoneIcon className={`${iconClasses} inline` }/>, 
    name: 'Contact Us', 
    submenu : [
      {
        path: '/app/contact-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Contact Lists',
      },

    ]
  },
  {
    path: '', 
    icon: <PhoneIcon className={`${iconClasses} inline` }/>, 
    name: 'Resource', 
    submenu : [
      {
        path: '/app/resource-add',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Add Resource',
      },
      {
        path: '/app/resource-view',
        icon: <EyeIcon className={submenuIconClasses}/>,
        name: 'Resources',
      },
    

    ]
  },
]

export default routes


