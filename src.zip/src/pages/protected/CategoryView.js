import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import CategoryPage from '../../features/category/viewCategory'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Categories"}))
      }, [])


    return(
        <CategoryPage />
    )
}

export default InternalPage