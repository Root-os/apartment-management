import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ContactPage from '../../features/contact/viewMessages'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : " Messages"}))
      }, [])


    return(
        <ContactPage />
    )
}

export default InternalPage