import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import BlogPage from '../../features/blogs/viewBlogs'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Blogs"}))
      }, [])


    return(
        <BlogPage/>
    )
}

export default InternalPage