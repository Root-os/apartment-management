import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import PartnerPage from '../../features/partner/viewPartner'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Partner"}))
      }, [])


    return(
        <PartnerPage />
    )
}

export default InternalPage