import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ApartmentForm from '../../features/apartment/addApartment'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Add Apartment"}))
      }, [])


    return(
        <ApartmentForm />
    )
}

export default InternalPage