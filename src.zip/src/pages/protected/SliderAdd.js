import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import SliderInsert from '../../features/slider/addslider'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Slider"}))
      }, [])


    return(
        <SliderInsert />
    )
}

export default InternalPage