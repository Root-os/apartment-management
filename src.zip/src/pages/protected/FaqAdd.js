import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import FAQInsert from '../../features/faq/addFaq'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : " Add FAQ"}))
      }, [])


    return(
        <FAQInsert />
    )
}

export default InternalPage