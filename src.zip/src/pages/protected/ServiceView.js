import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ServicePage from '../../features/services/viewServices'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Service"}))
      }, [])


    return(
        <ServicePage />
    )
}

export default InternalPage