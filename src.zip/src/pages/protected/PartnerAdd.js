import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import PartnerInsert from '../../features/partner/addPartner'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Partner"}))
      }, [])


    return(
        <PartnerInsert />
    )
}

export default InternalPage