import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ApartmentBooking from '../../features/bookApartment/addBooking'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Book Apartment"}))
      }, [])


    return(
        <ApartmentBooking/>
    )
}

export default InternalPage