import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import AboutPage from '../../features/aboutUs/viewAboutUs'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "About Us"}))
      }, [])


    return(
        <AboutPage />
    )
}

export default InternalPage