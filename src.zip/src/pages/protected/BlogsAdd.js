import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import BlogInsert from '../../features/blogs/addBlogs'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Blogs"}))
      }, [])


    return(
        <BlogInsert/>
    )
}

export default InternalPage