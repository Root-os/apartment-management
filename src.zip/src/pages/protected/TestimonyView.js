import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import TestimonyPage from '../../features/testimony/viewTestimony'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Testimonials"}))
      }, [])


    return(
        <TestimonyPage />
    )
}

export default InternalPage