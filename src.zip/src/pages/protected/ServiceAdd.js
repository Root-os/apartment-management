import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ServiceInsert from '../../features/services/addService'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Service"}))
      }, [])


    return(
        <ServiceInsert />
    )
}

export default InternalPage