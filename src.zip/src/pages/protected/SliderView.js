import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import SliderPage from '../../features/slider/viewSlider'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "View Sliders"}))
      }, [])


    return(
        <SliderPage />
    )
}

export default InternalPage