import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ResourcesPage from '../../features/resource/viewResource'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Resources"}))
      }, [])


    return(
        <ResourcesPage />
    )
}

export default InternalPage