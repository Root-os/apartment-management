import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../../features/common/headerSlice'
import PaymentReport from '../../../features/report/paymentReport'

function AllPaymentReport(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Payment  Report"}))
      }, [])


    return(
        <PaymentReport />
    )
}

export default AllPaymentReport