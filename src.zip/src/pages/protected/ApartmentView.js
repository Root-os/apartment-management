import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ApartmentPage from '../../features/apartment/viewApartment'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Apartments"}))
      }, [])


    return(
        <ApartmentPage />
    )
}

export default InternalPage