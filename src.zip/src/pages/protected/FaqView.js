import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import FaqsPage from '../../features/faq/viewFaq'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "FAQ"}))
      }, [])


    return(
        <FaqsPage />
    )
}

export default InternalPage