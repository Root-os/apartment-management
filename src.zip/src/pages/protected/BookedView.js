import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import BookedApartmentsPage from '../../features/bookApartment/viewbooked'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Booked Apartments"}))
      }, [])


    return(
        <BookedApartmentsPage/>
    )
}

export default InternalPage