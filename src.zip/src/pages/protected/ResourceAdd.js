import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import AddResourceForm from '../../features/resource/addResource'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Resources"}))
      }, [])


    return(
        <AddResourceForm />
    )
}

export default InternalPage