import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import CreateTestimony from '../../features/testimony/addTestimony'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Add Testimony"}))
      }, [])


    return(
        <CreateTestimony />
    )
}

export default InternalPage