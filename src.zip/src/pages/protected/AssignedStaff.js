import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import ComplaintsPage from '../../features/complaint-admin-side/viewAssignedStaff'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Bill Type"}))
      }, [])


    return(
        <ComplaintsPage />
    )
}

export default InternalPage