import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import CategoryInsert from '../../features/category/addCategory'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Add Category"}))
      }, [])


    return(
        <CategoryInsert/>
    )
}

export default InternalPage