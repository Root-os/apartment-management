import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { setPageTitle } from '../../features/common/headerSlice'
import GalleryInsert from '../../features/gallery/addGallery'

function InternalPage(){
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(setPageTitle({ title : "Gallery"}))
      }, [])


    return(
        <GalleryInsert />
    )
}

export default InternalPage