import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal } from 'react-responsive-modal';
import 'react-responsive-modal/styles.css'; 
import TitleCard from '../../components/Cards/TitleCard'

const FaqsPage = () => {
  const [faqs, setFaqs] = useState([]);
  const [selectedFaq, setSelectedFaq] = useState(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  // Fetch FAQs from the API
  useEffect(() => {
    const fetchFaqs = async () => {
      try {
        const response = await axios.get('https://website.smartbingogames.com/api/faq');
        setFaqs(response.data.faqs);
      } catch (error) {
        console.error('Error fetching FAQs:', error);
      }
    };

    fetchFaqs();
  }, []);

  // Handle Edit button click
  const handleEdit = (faq) => {
    setSelectedFaq(faq);
    setEditModalOpen(true);
  };

  // Handle Delete button click
  const handleDelete = (faq) => {
    setSelectedFaq(faq);
    setDeleteModalOpen(true);
  };

  // Handle Submit Edit
  const handleSubmitEdit = async (e) => {
    e.preventDefault();
    const updatedFaq = {
      question: e.target.question.value,
      answer: e.target.answer.value,
    };

    try {
      await axios.put(`https://website.smartbingogames.com/api/faq/${selectedFaq.id}`, updatedFaq);
      setFaqs(faqs.map((faq) => (faq.id === selectedFaq.id ? { ...faq, ...updatedFaq } : faq)));
      setEditModalOpen(false);
    } catch (error) {
      console.error('Error updating FAQ:', error);
    }
  };

  // Handle Delete Confirm
  const handleDeleteConfirm = async () => {
    try {
      await axios.delete(`https://website.smartbingogames.com/api/faq/${selectedFaq.id}`);
      setFaqs(faqs.filter((faq) => faq.id !== selectedFaq.id));
      setDeleteModalOpen(false);
    } catch (error) {
      console.error('Error deleting FAQ:', error);
    }
  };

  return (
    <><TitleCard title="FAQS" topMargin=""mt-6>

      {/* FAQ Table */}
      <table className="min-w-full shadow-md rounded-lg">
        <thead>
          <tr >
            <th className="py-2 px-4 border-b">Question</th>
            <th className="py-2 px-4 border-b">Answer</th>
            <th className="py-2 px-4 border-b">Actions</th>
          </tr>
        </thead>
        <tbody>
          {faqs.map((faq) => (
            <tr key={faq.id}>
              <td className="py-2 px-4 border-b">{faq.question}</td>
              <td className="py-2 px-4 border-b">{faq.answer}</td>
              <td className="py-2 px-4 border-b">
              <div className="inline-flex space-x-2">
                <button
                  className="bg-blue-500 text-white py-1 px-3 rounded-md hover:bg-blue-600"
                  onClick={() => handleEdit(faq)}
                >
                  Edit
                </button>
                <button
                  className="bg-red-500 text-white py-1 px-3 rounded-md hover:bg-red-600 ml-2"
                  onClick={() => handleDelete(faq)}
                >
                  Delete
                </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Edit Modal */}
      <Modal open={editModalOpen} onClose={() => setEditModalOpen(false)} center>
        <h2 className="text-2xl font-semibold mb-4">Edit FAQ</h2>
        {selectedFaq && (
          <form onSubmit={handleSubmitEdit}>
            <div className="mb-4">
              <label className="block mb-2">Question</label>
              <input
                type="text"
                name="question"
                defaultValue={selectedFaq.question}
                className="w-full p-2 rounded"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block mb-2">Answer</label>
              <textarea
                name="answer"
                defaultValue={selectedFaq.answer}
                className="w-full p-2  rounded"
                rows="4"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
            >
              Save Changes
            </button>
          </form>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal open={deleteModalOpen} onClose={() => setDeleteModalOpen(false)} center>
        <h2 className="text-xl font-semibold mb-4">Are you sure you want to delete this FAQ?</h2>
        <div className="flex justify-between">
          <button
            onClick={handleDeleteConfirm}
            className="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600"
          >
            Yes, Delete
          </button>
          <button
            onClick={() => setDeleteModalOpen(false)}
            className="bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600"
          >
            Cancel
          </button>
        </div>
      </Modal>
      </TitleCard>
    </>
  );
};

export default FaqsPage;
