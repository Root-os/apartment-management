import { useState } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText';
import TitleCard from '../../components/Cards/TitleCard'

function FAQInsert() {
    const INITIAL_FAQ_OBJ = {
        question: "",
        answer: "",
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [faqObj, setFaqObj] = useState(INITIAL_FAQ_OBJ);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for form fields
        if (faqObj.question.trim() === "") return setErrorMessage("Question is required.");
        if (faqObj.answer.trim() === "") return setErrorMessage("Answer is required.");

        try {
            setLoading(true);

            // Make the API request to insert the FAQ
            const response = await axios.post("https://website.smartbingogames.com/api/faq", faqObj);

            // Handle the success response
            if (response.data.message === "FAQ created successfully") {
                alert("FAQ created successfully!");
                // You can reset the form or do other things after success
                setFaqObj(INITIAL_FAQ_OBJ);
            } else {
                setErrorMessage("Failed to create FAQ.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setFaqObj({ ...faqObj, [updateType]: value });
    };

    return (
            <>
                <TitleCard title="Add FAQs">
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                {/* Question Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Question</label>
                                    <input
                                        type="text"
                                        value={faqObj.question}
                                        onChange={(e) => updateFormValue({ updateType: "question", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Answer Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Answer</label>
                                    <textarea
                                        value={faqObj.answer}
                                        onChange={(e) => updateFormValue({ updateType: "answer", value: e.target.value })}
                                        className="textarea textarea-bordered w-full"
                                    ></textarea>
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert FAQ
                            </button>
                        </form>
                    </TitleCard>
                </>
    );
}

export default FAQInsert;
