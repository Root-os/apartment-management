import { useState, useEffect } from "react";
import axios from "axios";
import moment from "moment";
import TitleCard from "../../components/Cards/TitleCard";
import SearchBar from "../../components/Input/SearchBar";
import { FunnelIcon, XMarkIcon } from '@heroicons/react/24/outline';

// Modal components for Edit, Delete, and View details
const EditCategoryModal = ({ category, isOpen, closeModal, updateCategory }) => {
  const [formData, setFormData] = useState({
    name: category ? category.name : "",
    type: category ? category.type : "",
    description: category ? category.description : "",
  });

  useEffect(() => {
    if (category) {
      setFormData({
        name: category.name || "",
        type: category.type || "",
        description: category.description || "",
      });
    }
  }, [category]);

  const handleSubmit = (e) => {
    e.preventDefault();
    updateCategory(formData);
  };

  if (!category) return null;  

  return (
    isOpen && (
      <div className="modal modal-open">
        <div className="modal-box">
          <h2>Edit Category</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              className="input input-bordered w-full mb-4"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Category Name"
            />
            <input
              type="text"
              className="input input-bordered w-full mb-4"
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              placeholder="Category Type"
            />
            <textarea
              className="textarea textarea-bordered w-full mb-4"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Category Description"
            />
            <div className="modal-action">
              <button type="submit" className="btn">Save Changes</button>
              <button type="button" className="btn btn-ghost" onClick={closeModal}>
                Close
              </button>
            </div>
          </form>
        </div>
      </div>
    )
  );
};


const DeleteConfirmationModal = ({ isOpen, category, deleteCategory, closeModal }) => {
  return (
    isOpen && (
      <div className="modal modal-open">
        <div className="modal-box">
          <h2>Are you sure you want to delete this category?</h2>
          <p>{category.name}</p>
          <div className="modal-action">
            <button className="btn" onClick={() => deleteCategory(category.id)}>
              Confirm
            </button>
            <button className="btn btn-ghost" onClick={closeModal}>
              Cancel
            </button>
          </div>
        </div>
      </div>
    )
  );
};

const CategoryDetailsModal = ({ category, isOpen, closeModal }) => {
  return (
    isOpen && (
      <div className="modal modal-open">
        <div className="modal-box">
          <h2>Category Details</h2>
          <p><strong>Name:</strong> {category.name}</p>
          <p><strong>Type:</strong> {category.type || "N/A"}</p>
          <p><strong>Description:</strong> {category.description || "No description available"}</p>
          <p><strong>Created At:</strong> {moment(category.createdAt).format("D MMM YYYY")}</p>
          <p><strong>Updated At:</strong> {moment(category.updatedAt).format("D MMM YYYY")}</p>
          <div className="modal-action">
            <button className="btn btn-ghost" onClick={closeModal}>
              Close
            </button>
          </div>
        </div>
      </div>
    )
  );
};

// TopSideButtons Component for Search and Filters
const TopSideButtons = ({ applySearch, removeFilter }) => {
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    if (searchText === "") {
      removeFilter();
    } else {
      applySearch(searchText);
    }
  }, [searchText]);

  return (
    <div className="inline-block float-right">
      <SearchBar searchText={searchText} styleClass="mr-4" setSearchText={setSearchText} />
    </div>
  );
};

function CategoryPage() {
  const [categories, setCategories] = useState([]);
  const [filteredCategories, setFilteredCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [sortOrder, setSortOrder] = useState("asc");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    axios
      .get("https://website.smartbingogames.com/api/category")
      .then((response) => {
        setCategories(response.data.categories);
        setFilteredCategories(response.data.categories);
      })
      .catch((error) => {
        console.error("Error fetching categories:", error);
      });
  }, []);

  const applySearch = (value) => {
    setSearchText(value);
    const filtered = categories.filter((category) =>
      category.name.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredCategories(filtered);
  };

  const removeFilter = () => {
    setSearchText("");
    setFilteredCategories(categories);
  };

  const handleSort = (column) => {
    const sortedCategories = [...filteredCategories];
    const order = sortOrder === "asc" ? "desc" : "asc";
    sortedCategories.sort((a, b) => {
      if (a[column] < b[column]) return order === "asc" ? -1 : 1;
      if (a[column] > b[column]) return order === "asc" ? 1 : -1;
      return 0;
    });

    setFilteredCategories(sortedCategories);
    setSortOrder(order);
  };

  const changePage = (newPage) => {
    if (newPage >= 1 && newPage <= Math.ceil(filteredCategories.length / rowsPerPage)) {
      setPage(newPage);
    }
  };

  const startIndex = (page - 1) * rowsPerPage;
  const endIndex = startIndex + rowsPerPage;

  const openEditModal = (category) => {
    setSelectedCategory(category);
    setEditModalOpen(true);
  };

  const closeEditModal = () => setEditModalOpen(false);

  const openDeleteModal = (category) => {
    setSelectedCategory(category);
    setDeleteModalOpen(true);
  };

  const closeDeleteModal = () => setDeleteModalOpen(false);

  const openDetailsModal = (category) => {
    setSelectedCategory(category);
    setDetailsModalOpen(true);
  };

  const closeDetailsModal = () => setDetailsModalOpen(false);

  const updateCategory = (formData) => {
    axios
      .put(`https://website.smartbingogames.com/api/category/${selectedCategory.id}`, formData)
      .then((response) => {
        setCategories((prevCategories) =>
          prevCategories.map((cat) =>
            cat.id === selectedCategory.id ? response.data : cat
          )
        );
        closeEditModal();
      })
      .catch((error) => console.error("Error updating category:", error));
  };

  const deleteCategory = (id) => {
    axios
      .delete(`https://website.smartbingogames.com/api/category/${id}`)
      .then(() => {
        setCategories((prevCategories) =>
          prevCategories.filter((category) => category.id !== id)
        );
        closeDeleteModal();
      })
      .catch((error) => console.error("Error deleting category:", error));
  };

  return (
    <>
      <TitleCard title="Categories" topMargin="mt-2" TopSideButtons={<TopSideButtons applySearch={applySearch} removeFilter={removeFilter} />}>
        <div className="overflow-x-auto w-full">
          <table className="table w-full">
            <thead>
              <tr>
                <th onClick={() => handleSort("name")} className="cursor-pointer">Name</th>
                <th onClick={() => handleSort("type")} className="cursor-pointer">Type</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCategories.slice(startIndex, endIndex).map((category) => (
                <tr key={category.id}>
                  <td>{category.name}</td>
                  <td>{category.type || "N/A"}</td>
                  <td>
                    <button className="btn btn-sm  mr-2" onClick={() => openDetailsModal(category)}>
                      Details
                    </button>
                    <button className="btn btn-sm btn-primary mr-2" onClick={() => openEditModal(category)}>
                      Edit
                    </button>
                    <button className="btn btn-sm btn-danger bg-red-500" onClick={() => openDeleteModal(category)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center mt-4">
          <div className="flex items-center">
            {/* <span>Rows per page:</span> */}
            <select className="ml-2 select select-bordered w-10" value={rowsPerPage} onChange={(e) => setRowsPerPage(Number(e.target.value))}>
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="20">20</option>
            </select>
          </div>

          <div className="flex items-center">
            <button className="btn btn-sm btn-ghost" onClick={() => changePage(page - 1)} disabled={page === 1}>
              Prev
            </button>
            <span className="mx-2">{page}</span>
            <button
              className="btn btn-sm btn-ghost"
              onClick={() => changePage(page + 1)}
              disabled={page === Math.ceil(filteredCategories.length / rowsPerPage)}
            >
              Next
            </button>
          </div>
        </div>
      </TitleCard>

      {/* Modals */}
      <EditCategoryModal category={selectedCategory} isOpen={editModalOpen} closeModal={closeEditModal} updateCategory={updateCategory} />
      <DeleteConfirmationModal isOpen={deleteModalOpen} category={selectedCategory} deleteCategory={deleteCategory} closeModal={closeDeleteModal} />
      <CategoryDetailsModal category={selectedCategory} isOpen={detailsModalOpen} closeModal={closeDetailsModal} />
    </>
  );
}

export default CategoryPage;
