import { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ErrorText from '../../components/Typography/ErrorText'; 
import TitleCard from '../../components/Cards/TitleCard'

function CategoryInsert() {
    const INITIAL_CATEGORY_OBJ = {
        name: "",
        type: "",
        description: "",
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [categoryObj, setCategoryObj] = useState(INITIAL_CATEGORY_OBJ);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for empty fields
        if (categoryObj.name.trim() === "")
            return setErrorMessage("Name is required.");
        if (categoryObj.type.trim() === "")
            return setErrorMessage("Type is required.");
        if (categoryObj.description.trim() === "")
            return setErrorMessage("Description is required.");

        try {
            setLoading(true);

            
            const payload = {
                name: categoryObj.name,
                type: categoryObj.type,
                description: categoryObj.description,
            };

            // Make the API request to insert the category
            const response = await axios.post("https://website.smartbingogames.com/api/category", payload);
            if (response.data.message === "Category created successfully") {
                window.location.href = '/app/category-view'; 
        
            } else {
                setErrorMessage("Failed to create category.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setCategoryObj({ ...categoryObj, [updateType]: value });
    };

    return (
     <>
     <TitleCard title="Add Category" topMargin="mt-6">
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                {/* Name Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Category Name</label>
                                    <input
                                        type="text"
                                        value={categoryObj.name}
                                        onChange={(e) => updateFormValue({ updateType: "name", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Type Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Category Type</label>
                                    <input
                                        type="text"
                                        value={categoryObj.type}
                                        onChange={(e) => updateFormValue({ updateType: "type", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Description Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Description</label>
                                    <textarea
                                        value={categoryObj.description}
                                        onChange={(e) => updateFormValue({ updateType: "description", value: e.target.value })}
                                        className="textarea textarea-bordered w-full"
                                    ></textarea>
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Category
                            </button>

                            {/* Link to another page (e.g., Categories List) */}
                            {/* <div className="text-center mt-4">
                                <Link to="/app/categories">
                                    <span className="inline-block hover:text-primary hover:underline hover:cursor-pointer transition duration-200">
                                        View Categories
                                    </span>
                                </Link>
                            </div> */}
                        </form>
                        </TitleCard>
                    </>
    );
}

export default CategoryInsert;
