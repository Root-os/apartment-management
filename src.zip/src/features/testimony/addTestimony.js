import React, { useState, useEffect } from "react";
import axios from "axios";

import { useNavigate } from 'react-router-dom';

const CreateTestimony = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    description: "",
    service: "",
    company: "",
    image: null,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [modalMessage, setModalMessage] = useState("");  // For storing modal message
  const [modalMessageType, setModalMessageType] = useState(null);  // For storing message type (success or error)

  const [services, setServices] = useState([]);  

  // Fetch services from the API
  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get("https://website.smartbingogames.com/api/service");

        console.log("API Response:", response.data);

        if (response.data && Array.isArray(response.data.services)) {
          setServices(response.data.services);  // Set services to the state
        } else {
          setError("Services not found in the response.");
        }
      } catch (err) {
        console.error("Error fetching services:", err);
        setError("An error occurred while fetching services.");
      }
    };

    fetchServices();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files ? e.target.files[0] : null;
    setFormData((prevState) => ({
      ...prevState,
      image: file,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);  // Clear previous error messages
    setModalMessage("");  // Reset modal message before form submission
    setModalMessageType(null);  // Reset modal message type
    setLoading(true);
    const formDataToSend = new FormData();
    formDataToSend.append("description", formData.description);
    formDataToSend.append("service", formData.service);
    formDataToSend.append("company", formData.company);
    if (formData.image) {
      formDataToSend.append("image", formData.image);
    }

    try {
      const response = await axios.post('${process.env.REACT_APP_BASE_URL}testimony', formDataToSend, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      if (response.status === 201) {
        setModalMessage("An error occurred. Please try again.");
        setModalMessageType("error");
      } else {
        console.log(response.data);
        
        setModalMessage("Testimony submitted successfully!");
        setModalMessageType("success");
      
        setTimeout(() => {
          navigate('/ViewTestimony');
        }, 2000);
      }
    } catch (err) {
      console.error("Error during form submission:", err);
      setModalMessage("An error occurred. Please try again.");
      setModalMessageType("error");
    } finally {
      setLoading(false);
    }
  };

  const handleModalClose = () => {
    setModalMessage("");
    setModalMessageType(null);
  };

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 border rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold mb-6">Add Testimony</h1>
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            value={formData.description}
            onChange={handleChange}
            className="mt-1 p-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500"
            required
          />
        </div>

        <div>
          <label htmlFor="service" className="block text-sm font-medium text-gray-700">
            Service
          </label>
          <select
            id="service"
            name="service"
            value={formData.service}
            onChange={handleChange}
            className="mt-1 p-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500"
            required
          >
            <option value="">Select a service</option>
            {services.map((service) => (
              <option key={service.id} value={service.id.toString()}>
                {service.title}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="company" className="block text-sm font-medium text-gray-700">
            Company
          </label>
          <input
            type="text"
            id="company"
            name="company"
            value={formData.company}
            onChange={handleChange}
            className="mt-1 p-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500"
            required
          />
        </div>

        <div>
          <label htmlFor="image" className="block text-sm font-medium text-gray-700">
            Image (Optional)
          </label>
          <input
            type="file"
            id="image"
            name="image"
            onChange={handleFileChange}
            accept="image/*"
            className="mt-1 p-2 w-full border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-between">
        <button
          type="submit"
          className={`mt-4 w-full rounded-lg py-3 text-base font-semibold text-white transition-all ${
            loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-primary'
          }`}
          disabled={loading}
          >
            {loading ? 'Submitting' : 'Submit'}
        </button>
        </div>
      </form>
      </>
    </div>
  );
};

export default CreateTestimony;
