import React, { useState, useEffect } from 'react';
import axios from 'axios';


const TestimonyPage = () => {
  const [loading, setLoading] = useState(true);
  const [testimonies, setTestimonies] = useState([]);
  const [services, setServices] = useState([]); // Add state to store services
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  // State for the modal
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [testimonyToUpdate, setTestimonyToUpdate] = useState(null);
  const [testimonyToDelete, setTestimonyToDelete] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);

  // State for the success/error modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(null);

  // Fetch the services from the API
  const fetchServices = async () => {
    try {
      const response = await axios.get(`https://website.smartbingogames.com/api/service`);
      setServices(response.data.services);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  };

  useEffect(() => {
    fetchServices(); // Fetch services when component mounts
  }, []);

  // Fetch testimonies (already in your code)
  const fetchTestimonies = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_BASE_URL}testimony`);
      setTestimonies(response.data.testimonies);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching testimonies:', error);
      setLoading(false);
    }
  };

  // Call fetchTestimonies initially
  useEffect(() => {
    fetchTestimonies();
  }, []);

  const getServiceTitleById = (serviceId) => {
    const service = services.find((service) => service.id === serviceId);
    return service ? service.title : 'Unknown Service';
  };

  const updateTestimony = async (id, updatedTestimony) => {
    try {
      const formData = new FormData();
      formData.append('description', updatedTestimony.description);
      formData.append('service', updatedTestimony.service);
      formData.append('company', updatedTestimony.company);
      if (selectedImage) {
        formData.append('image', selectedImage);
      }

      await axios.put(`https://website.smartbingogames.com/api/testimony/${id}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setIsUpdateModalOpen(false);
      fetchTestimonies(); // Refresh testimonies after update
      setMessage('Testimony updated successfully!');
      setMessageType('success');
      setIsModalOpen(true);
    } catch (error) {
      console.error('Error updating testimony:', error);
      setMessage('Failed to update testimony.');
      setMessageType('error');
      setIsModalOpen(true);
    }
  };

  const deleteTestimony = async (id) => {
    try {
      await axios.delete(`https://website.smartbingogames.com/api/testimony/${id}`);
      setIsDeleteModalOpen(false);
      fetchTestimonies(); // Refresh testimonies after deletion
      setMessage('Testimony deleted successfully!');
      setMessageType('success');
      setIsModalOpen(true);
    } catch (error) {
      console.error('Error deleting testimony:', error);
      setMessage('Failed to delete testimony.');
      setMessageType('error');
      setIsModalOpen(true);
    }
  };

  const handlePageChange = (page) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const handleRowsPerPageChange = (e) => {
    setRowsPerPage(Number(e.target.value));
    setCurrentPage(1); // Reset to the first page when the number of rows changes
  };

  // Filter testimonies based on search query
  const filteredTestimonies = testimonies.filter(
    (testimony) =>
      testimony.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      testimony.service.toLowerCase().includes(searchQuery.toLowerCase()) ||
      testimony.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pagination logic
  const totalPages = Math.ceil(filteredTestimonies.length / rowsPerPage);
  const indexOfLastTestimony = currentPage * rowsPerPage;
  const indexOfFirstTestimony = indexOfLastTestimony - rowsPerPage;
  const currentTestimonies = filteredTestimonies.slice(indexOfFirstTestimony, indexOfLastTestimony);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Testimonies</h1>
        <>
          {/* Search Bar */}
          <div className="mb-4 ">
            <input
              type="text"
              placeholder="Search testimonies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-1/3 p-2  rounded-md"
            />
          </div>

          {/* Testimony Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full table-auto border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="px-4 py-2 border-b">Company</th>
                  <th className="px-4 py-2 border-b">Service</th>
                  <th className="px-4 py-2 border-b">Description</th>
                  <th className="px-4 py-2 border-b">Image</th>
                  <th className="px-4 py-2 border-b">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentTestimonies.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-2 text-center">
                      No testimonies found.
                    </td>
                  </tr>
                ) : (
                  currentTestimonies.map((testimony) => (
                    <tr key={testimony.id} className="border-b">
                      <td className="px-4 py-2">{testimony.company}</td>
                      <td className="px-4 py-2">{getServiceTitleById(Number(testimony.service))}</td>
                      <td className="px-4 py-2">{testimony.description}</td>
                      <td className="px-4 py-2">
                        <img
                          src={testimony.image}
                          alt="Testimony"
                          className="w-20 h-20 object-cover rounded-full"
                        />
                      </td>
                      <td className="px-4 py-2 text-center">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setTestimonyToUpdate(testimony);
                              setIsUpdateModalOpen(true);
                            }}
                            className="p-2 border rounded-md bg-blue-500 text-white w-1/2"
                          >
                            Update
                          </button>
                          <button
                            onClick={() => {
                              setTestimonyToDelete(testimony);
                              setIsDeleteModalOpen(true);
                            }}
                            className="p-2 border rounded-md bg-red-500 text-white w-1/2"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination and Rows Per Page */}
          <div className="flex justify-between items-center mt-4">
            <select
              value={rowsPerPage}
              onChange={handleRowsPerPageChange}
              className="p-2 border rounded-md"
            >
              <option value={5}>5 rows</option>
              <option value={10}>10 rows</option>
              <option value={15}>15 rows</option>
            </select>

            <div className="flex space-x-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-gray-200 rounded-md"
              >
                Prev
              </button>
              <span>
                Page {currentPage} 
              </span>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-gray-200 rounded-md"
              >
                Next
              </button>
            </div>
          </div>

          {/* Update Modal */}
          {isUpdateModalOpen && testimonyToUpdate && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
              <div className="bg-white p-6 rounded-md w-96">
                <h3 className="text-2xl font-semibold mb-4">Update Testimony</h3>
                <label>Description</label>
                <input
                  type="text"
                  value={testimonyToUpdate.description}
                  onChange={(e) => setTestimonyToUpdate({ ...testimonyToUpdate, description: e.target.value })}
                  className="w-full p-3 border rounded-md mb-4"
                />
                <label>Service</label>
                <select
                  value={testimonyToUpdate.service}
                  onChange={(e) =>
                    setTestimonyToUpdate({ ...testimonyToUpdate, service: e.target.value })
                  }
                  className="w-full p-3 border rounded-md mb-4"
                >
                  {services.map((service) => (
                    <option key={service.id} value={service.title}>
                      {service.title}
                    </option>
                  ))}
                </select>
                <label>Company</label>
                <input
                  type="text"
                  value={testimonyToUpdate.company}
                  onChange={(e) => setTestimonyToUpdate({ ...testimonyToUpdate, company: e.target.value })}
                  className="w-full p-3 border rounded-md mb-4"
                />
                <label>Image</label>
                <input
                  type="file"
                  onChange={(e) => setSelectedImage(e.target.files ? e.target.files[0] : null)}
                  className="w-full p-3 border rounded-md mb-4"
                />
                <button
                  onClick={() => updateTestimony(testimonyToUpdate.id, testimonyToUpdate)}
                  className="w-1/2 p-2 bg-blue-500 text-white rounded-md"
                >
                  Update
                </button>
                <button
                  onClick={() => setIsUpdateModalOpen(false)}
                  className="w-1/2 p-2 bg-gray-500 text-white rounded-md"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Delete Modal */}
          {isDeleteModalOpen && testimonyToDelete && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
              <div className="bg-white p-6 rounded-md w-96">
                <h3 className="text-2xl font-semibold mb-4">Are you sure you want to delete this testimony?</h3>
                <div className="flex space-x-4">
                  <button
                    onClick={() => deleteTestimony(testimonyToDelete.id)}
                    className="px-4 py-2 bg-red-500 text-white rounded-md"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setIsDeleteModalOpen(false)}
                    className="px-4 py-2 bg-gray-500 text-white rounded-md"
                  >
                    No
                  </button>
                </div>
              </div>
            </div>
          )}
         
        </>
      
    </div>
  );
};

export default TestimonyPage;
