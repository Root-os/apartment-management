import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TitleCard from '../../components/Cards/TitleCard'

const ApartmentPage = () => {
  const [loading, setLoading] = useState(true);
  const [apartments, setApartments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [selectedApartment, setSelectedApartment] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(null);
  const [newImage, setNewImage] = useState(null); // New state for the image
  const [updatedApartment, setUpdatedApartment] = useState(null);

  useEffect(() => {
    const fetchApartments = async () => {
      try {
        const response = await axios.get('https://website.smartbingogames.com/api/apartment');
        setApartments(response.data);
        setIsLoading(false);
      } catch (err) {
        setError(`Failed to load apartments`);
        setIsLoading(false);
      }
    };
    fetchApartments();
  }, []);

  const filteredApartments = apartments.filter((apartment) =>
    apartment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apartment.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastApartment = currentPage * rowsPerPage;
  const indexOfFirstApartment = indexOfLastApartment - rowsPerPage;
  const currentApartments = filteredApartments.slice(indexOfFirstApartment, indexOfLastApartment);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleDeleteApartment = async () => {
    if (selectedApartment) {
      try {
        await axios.delete(`https://website.smartbingogames.com/api/apartment/${selectedApartment.id}`);
        setApartments(apartments.filter((apartment) => apartment.id !== selectedApartment.id));
        setMessage('Apartment deleted successfully');
        setMessageType('success');
      } catch (err) {
        setMessage('Failed to delete apartment');
        setMessageType('error');
      }
      setIsDeleteModalOpen(false);
      setSelectedApartment(null); // Reset selected apartment
    }
  };

  const openDeleteModal = (apartment) => {
    setSelectedApartment(apartment);
    setIsDeleteModalOpen(true);
  };

  const handleUpdateApartment = async () => {
    if (updatedApartment) {
      const formData = new FormData();

      // Append apartment data
      formData.append('title', updatedApartment.title);
      formData.append('location', updatedApartment.location);
      formData.append('availableFrom', updatedApartment.availableFrom);
      formData.append('availableTo', updatedApartment.availableTo);
      formData.append('noRoom', updatedApartment.noRoom);
      formData.append('features', JSON.stringify(updatedApartment.features)); // Send features as JSON

      // Append the image if a new one is selected
      if (newImage) {
        formData.append('imageUrl', newImage);
      }

      try {
        const response = await axios.put(
          `https://website.smartbingogames.com/api/apartment/${updatedApartment.id}`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          }
        );

        // Update apartment data in state
        setApartments(
          apartments.map((apartment) =>
            apartment.id === updatedApartment.id ? updatedApartment : apartment
          )
        );

        setMessage('Apartment updated successfully');
        setMessageType('success');
      } catch (err) {
        console.log('Error while updating apartment:', err);
        setMessage('Failed to update apartment');
        setMessageType('error');
      }
      setIsUpdateModalOpen(false);
    }
  };

  const openUpdateModal = (apartment) => {
    setSelectedApartment(apartment);
    setUpdatedApartment({ ...apartment });
    setIsUpdateModalOpen(true);
    setNewImage(null); // Reset the selected image when opening the modal
  };

  const handleUpdateChange = (field, value) => {
    if (updatedApartment) {
      setUpdatedApartment({
        ...updatedApartment,
        [field]: value,
      });
    }
  };

  const handleFeatureChange = (e, feature) => {
    setUpdatedApartment((prevUpdatedApartment) => {
      if (prevUpdatedApartment === null) {
        return prevUpdatedApartment; // Handle null as needed
      }

      const updatedFeatures = {
        ...prevUpdatedApartment.features,
        [feature]: e.target.checked ? true : false, // Make sure the value is boolean
      };

      return {
        ...prevUpdatedApartment,
        features: updatedFeatures,
      };
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files ? e.target.files[0] : null;
    if (file) {
      setNewImage(file); // Store the new image file
    }
  };

  const handleRowsPerPageChange = (e) => {
    setRowsPerPage(Number(e.target.value));
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  if (error) return <p>{error}</p>;

  const getFullImageUrl = (url) => {
    // Check if url is valid and starts with 'http', otherwise return a default or fallback image URL
    return url && url.startsWith('http') ? url : `https://website.smartbingogames.com${url}`;
  };
  console.log(getFullImageUrl);

  return (
    <><TitleCard title="Apartments" topMargin=""mt-6>
    
        <div className="mb-4">
          <input
            type="text"
            placeholder="Search by title or location"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border rounded"
          />
        </div>

        {filteredApartments.length === 0 ? (
          <p>No apartments available</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {currentApartments.map((apartment) => (
              <div key={apartment.id} className="border p-4 rounded-lg shadow-lg hover:shadow-xl hover:bg-gray-100 transition-all transform hover:scale-105">
                <div className="mb-4">
                  <img
                    src={getFullImageUrl(apartment.imageUrl)} // Use the full image URL here
                    alt={apartment.title}
                    className="w-full h-48 object-cover rounded-md mb-4"
                  />
                </div>
                <h2 className="text-xl font-semibold">{apartment.title}</h2>
                <p className="text-gray-600">{apartment.location}</p>
                <p className="text-gray-500">Rooms: {apartment.noRoom}</p>
                <p className="text-sm text-gray-500">
                  Available from: {new Date(apartment.availableFrom).toLocaleDateString()} to{' '}
                  {new Date(apartment.availableTo).toLocaleDateString()}
                </p>
                <div className="mt-4 flex justify-between">
                  <button
                    onClick={() => openUpdateModal(apartment)}
                    className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => openDeleteModal(apartment)}
                    className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 flex justify-between items-center">
          <select
            value={rowsPerPage}
            onChange={handleRowsPerPageChange}
            className="px-4 py-2 border rounded"
          >
            <option value={15}>15</option>
            <option value={20}>20</option>
            <option value={25}>25</option>
          </select>

          <div className="flex items-center">
            <button
              onClick={() => paginate(currentPage - 1)}
              disabled={currentPage === 1}
              className="px-4 py-2 border rounded mr-2 disabled:opacity-50 bg-blue-500"
            >
              &lt;
            </button>
            <button
              onClick={() => paginate(currentPage + 1)}
              disabled={currentPage * rowsPerPage >= filteredApartments.length}
              className="px-4 py-2 border rounded disabled:opacity-50 bg-blue-500"
            >
              &gt;
            </button>
          </div>
        </div>

      {isDeleteModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-md shadow-lg max-w-lg w-full">
            <h3 className="text-lg mb-4 text-black">Are you sure you want to delete this apartment?</h3>
            <div className="mt-4 flex justify-end space-x-4">
              <button
                onClick={handleDeleteApartment}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
              >
                Yes
              </button>
              <button
                onClick={() => setIsDeleteModalOpen(false)}
                className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {isUpdateModalOpen && updatedApartment && (
        <div className="fixed bg-base-300 inset-0 flex items-center justify-center bg-opacity-50 z-50 w-full">
          <div className="bg-base-300 w-full p-6 rounded-lg shadow-lg max-w-sm w-full max-h-[80vh] overflow-auto">
            <button
              onClick={() => setIsUpdateModalOpen(false)}
              className="absolute top-2 right-2 text-xl text-gray-500 hover:text-gray-700"
            >
              &times;
            </button>
            <div>
              <h2 className="text-xl font-bold mb-4">Update Apartment</h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleUpdateApartment();
                }}
              >
                {/* Title */}
                <div className="mb-4">
                  <label className="block mb-2">Title</label>
                  <input
                    type="text"
                    value={updatedApartment.title}
                    onChange={(e) => handleUpdateChange('title', e.target.value)}
                    className="px-4 py-2 border rounded w-full"
                  />
                </div>
                <div className="mb-4">
                  <label className="block mb-2">Location</label>
                  <input
                    type="text"
                    value={updatedApartment.location}
                    onChange={(e) => handleUpdateChange('location', e.target.value)}
                    className="px-4 py-2 border rounded w-full"
                  />
                </div>
                {/* <div className="mb-4">
                  <h4 className="font-semibold text-lg">Features</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4 max-h-[50vh] overflow-auto">
                    {['pool', 'gym', 'parking', 'wifi', 'ac', 'security', 'balcony', 'laundry', 'elevator', 'furnished', 'petFriendly', 'smartHome', 'heating', 'fireplace', 'dishwasher', 'cinema'].map((feature) => (
                      <div className="flex items-center space-x-2" key={feature}>
                        <label htmlFor={feature} className="text-sm text-gray-600 capitalize">{feature}</label>
                        <input
                          type="checkbox"
                          name={feature}
                          checked={updatedApartment.features[feature] === 'true' || updatedApartment.features[feature] === true}
                          onChange={(e) => handleFeatureChange(e, feature)}
                        />
                      </div>
                    ))}
                  </div>
                </div> */}

                {/* Image */}
                <div className="mb-4">
                  <label className="block mb-2">Image</label>
                  <input
                    type="file"
                    onChange={handleImageChange}
                    className="px-4 py-2 border rounded w-full"
                  />
                </div>

                {/* Action buttons */}
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-blue-500 text-white px-4 py-2 rounded-md"
                  >
                  Save 
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsUpdateModalOpen(false)}
                    className="bg-gray-500 text-white px-4 py-2 rounded-md ml-4"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </TitleCard>
    </>
  );
};

export default ApartmentPage;
