import React, { useState } from 'react';
import axios from 'axios';
import TitleCard from '../../components/Cards/TitleCard'

import { useNavigate } from 'react-router-dom';

const ApartmentForm = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [noRoom, setNoRoom] = useState(0);
  const [availableFrom, setAvailableFrom] = useState('');
  const [availableTo, setAvailableTo] = useState('');

  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null); 
  const [features, setFeatures] = useState({
    pool: false,
    gym: false,
    security: false,
    ac: false,
    wifi: false,
    parking: false,
    Cinema: false,
    dishwasher: false,
    fireplace: false,
    heating: false,
    smartHome: false,
    petFriendly: false,
    furnished: false,
    elevator: false,
    laundry: false,
    Cafteria: false,
  });
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(null);
  const [loading, setLoading] = useState(false);
  
  // State to control modal visibility
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleFeatureChange = (e, feature) => {
    setFeatures({ ...features, [feature]: e.target.checked });
  };

  const handleImageChange = (e) => {
    const file = e.target.files ? e.target.files[0] : null;
    if (file) {
      setImage(file);
      const previewUrl = URL.createObjectURL(file); 
      setImagePreview(previewUrl); 
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('location', location);
    formData.append('noRoom', noRoom.toString());
    formData.append('availableFrom', availableFrom);
    formData.append('availableTo', availableTo);

    formData.append('features', JSON.stringify(features)); 

    if (image) {
      formData.append('image', image);
    }

    setMessage('');
    setLoading(true);

    try {
      const response = await axios.post('https://website.smartbingogames.com/api/apartment', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      if (response.status === 201) {
        setMessage('Apartment added successfully!');
        setMessageType('success');

      } else {
        setMessage('Failed to add apartment.');
        setMessageType('error');
      }
    } catch (err) {
      console.error('Error submitting form:', err);
      setMessage('Error submitting the form. Please try again later.');
      setMessageType('error');
    } finally {
      setIsModalOpen(true);
      setTitle('');
      setLocation('');
      setNoRoom(0);
      setAvailableFrom('');
      setAvailableTo('');
      setImage(null);
      setLoading(false);
    }
  };

  return (
    <>
      <TitleCard title="Add Apartment" topMargin=""mt-6>
        <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-white-700">
                Apartment Title
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="input input-bordered w-full"
              />
            </div>
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-white-700">
                Description
              </label>
              <textarea
                name="description"
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                className="input input-bordered w-full"
              />
            </div>
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-white-700">
                Location
              </label>
              <input
                type="text"
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="input input-bordered w-full"
              />
            </div>
            <div>
              <label htmlFor="noRoom" className="block text-sm font-medium text-white-700">
                Number of Rooms
              </label>
              <input
                type="number"
                id="noRoom"
                value={noRoom}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  if (value >= 1 && value <= 10) {
                    setNoRoom(value);
                  }
                }}
                min="1"
                max="10"
                required
                className="input input-bordered w-full"
              />
            </div>
            <div className="space-y-4">
              <div>
                <label htmlFor="availableFrom" className="block text-lg font-semibold text-white-800">
                  Available From
                </label>
                <input
                  type="date"
                  id="availableFrom"
                  value={availableFrom}
                  onChange={(e) => setAvailableFrom(e.target.value)}
                  required
                  className="input input-bordered w-full"
                />
              </div>
              <div>
                <label htmlFor="availableTo" className="block text-sm font-medium text-white-700">
                  Available To
                </label>
                <input
                  type="date"
                  id="availableTo"
                  value={availableTo}
                  onChange={(e) => setAvailableTo(e.target.value)}
                  required
                  className="input input-bordered w-full"
                />
              </div>
            </div>
            <div>
              <label htmlFor="image" className="block text-lg font-semibold text-white-800">
                Upload Image (Optional)
              </label>
              <input
                type="file"
                id="image"
                onChange={handleImageChange}
                className="input input-bordered w-full"
              />
              {imagePreview && (
                <div className="mt-4">
                  <img src={imagePreview} 
                       alt="Selected Preview" 
                       className="w-32 h-32 object-cover rounded-md" />
                </div>
              )}
            </div>
            <div className=" p-6 rounded-lg shadow-md border border-gray-200">
              <h3 className="text-lg font-semibold text-white-800">Apartment Includes</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
                {/* Features Checkbox Group */}
                {Object.keys(features).map((feature) => (
                  <div key={feature} className="flex items-center space-x-2">
                    <label htmlFor={feature} className="text-sm text-white-600">{feature}</label>
                    <input
                      type="checkbox"
                      id={feature}
                      checked={features[feature]}
                      onChange={(e) => handleFeatureChange(e, feature)}
                      className="h-5 w-5 text-blue-500 rounded-md focus:ring-2 focus:ring-blue-300"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className={`mt-4 w-full rounded-lg py-3 text-base font-semibold text-white transition-all ${
                  loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-primary'
                }`}
                disabled={loading}
              >
                {loading ? 'Submitting' : 'Submit'}
              </button>
            </div>
          </form>
    </TitleCard></>
  );
};

export default ApartmentForm;
