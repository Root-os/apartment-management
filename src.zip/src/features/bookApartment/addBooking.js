import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText'; // Assuming you have ErrorText component for error display

function ApartmentBooking() {
    const [users, setUsers] = useState([]);
    const [apartments, setApartments] = useState([]);
    const [bookingDetails, setBookingDetails] = useState({
        userId: "",
        apartmentId: "",
        startDate: "",
        endDate: "",
        totalPrice: 0,
        status: "pending",
    });
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");

    // Fetch users and apartments data on component mount
    useEffect(() => {
        // Fetch users data
        axios.get("https://website.smartbingogames.com/api/user/all")
            .then(response => {
                setUsers(response.data.users);
            })
            .catch(error => {
                setErrorMessage("Error fetching users data.");
            });

        // Fetch apartments data (assuming there's an API to get apartments)
        axios.get("https://website.smartbingogames.com/api/apartment")
            .then(response => {
                setApartments(response.data);  // Assuming the response contains a list of apartments
            })
            .catch(error => {
                setErrorMessage("Error fetching apartments data.");
            });
    }, []);

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        setBookingDetails(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validate the form
        if (!bookingDetails.userId || !bookingDetails.apartmentId || !bookingDetails.startDate || !bookingDetails.endDate || !bookingDetails.totalPrice) {
            return setErrorMessage("All fields are required.");
        }

        try {
            setLoading(true);

            // Post the booking data to the API
            const response = await axios.post("https://website.smartbingogames.com/api/booking", bookingDetails);
            
            if (response.data.message === "Booking created successfully") {
                alert("Apartment booked successfully!");
                setBookingDetails({
                    userId: "",
                    apartmentId: "",
                    startDate: "",
                    endDate: "",
                    totalPrice: 0,
                    status: "pending",
                });
            } else {
                setErrorMessage("Failed to create booking.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-base-200 flex items-center">
            <div className="card mx-auto w-full max-w-5xl shadow-xl">
                <div className="grid md:grid-cols-2 grid-cols-1 bg-base-100 rounded-xl items-center">
                    <div className="py-24 px-10">
                        <h2 className="text-2xl font-semibold mb-2 text-center">Book an Apartment</h2>
                        <form onSubmit={submitForm}>
                            {/* User Selection */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">User</label>
                                <select
                                    name="userId"
                                    value={bookingDetails.userId}
                                    onChange={handleFormChange}
                                    className="select select-bordered w-full"
                                >
                                    <option value="">Select User</option>
                                    {users.map((user) => (
                                        <option key={user.id} value={user.id}>
                                            {user.username}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {/* Apartment Selection */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">Apartment</label>
                                <select
                                    name="apartmentId"
                                    value={bookingDetails.apartmentId}
                                    onChange={handleFormChange}
                                    className="select select-bordered w-full"
                                >
                                    <option value="">Select Apartment</option>
                                    {apartments.map((apartment) => (
                                        <option key={apartment.id} value={apartment.id}>
                                            {apartment.title} - {apartment.location}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {/* Start Date */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">Start Date</label>
                                <input
                                    type="datetime-local"
                                    name="startDate"
                                    value={bookingDetails.startDate}
                                    onChange={handleFormChange}
                                    className="input input-bordered w-full"
                                />
                            </div>

                            {/* End Date */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">End Date</label>
                                <input
                                    type="datetime-local"
                                    name="endDate"
                                    value={bookingDetails.endDate}
                                    onChange={handleFormChange}
                                    className="input input-bordered w-full"
                                />
                            </div>

                            {/* Total Price (Editable Field) */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">Total Price</label>
                                <input
                                    type="number"
                                    name="totalPrice"
                                    value={bookingDetails.totalPrice}
                                    onChange={handleFormChange}
                                    className="input input-bordered w-full"
                                    placeholder="Enter Total Price"
                                />
                            </div>

                            {/* Error Message */}
                            <ErrorText>{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Book Apartment
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ApartmentBooking;
