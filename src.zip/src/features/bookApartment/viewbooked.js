import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal } from 'react-responsive-modal';
import 'react-responsive-modal/styles.css'; 
import TitleCard from '../../components/Cards/TitleCard';

const BookedApartmentsPage = () => {
  const [bookings, setBookings] = useState([]);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false); // Modal state for deletion confirmation
  const [selectedBookingForDelete, setSelectedBookingForDelete] = useState(null); // Booking selected for deletion

  // Fetch booked apartments
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get('https://website.smartbingogames.com/api/booking');
        setBookings(response.data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    fetchBookings();
  }, []);

  // Handle status change and immediately update the status
  const handleStatusChange = async (bookingId, newStatus) => {
    try {
      // Update the status on the API
      await axios.put(`https://website.smartbingogames.com/api/booking/${bookingId}`, {
        status: newStatus,
      });

      // Update the status in the local state
      setBookings(bookings.map((booking) => 
        booking.id === bookingId ? { ...booking, status: newStatus } : booking
      ));
    } catch (error) {
      console.error('Error updating booking status:', error);
    }
  };

  // Handle Delete button click
  const handleDelete = (booking) => {
    setSelectedBookingForDelete(booking);
    setDeleteModalOpen(true); // Open the modal to confirm deletion
  };

  // Handle Delete Confirmation
  const handleDeleteConfirm = async () => {
    try {
      // Send DELETE request to the API
      await axios.delete(`https://website.smartbingogames.com/api/booking/${selectedBookingForDelete.id}`);

      // Remove the deleted booking from the local state
      setBookings(bookings.filter((booking) => booking.id !== selectedBookingForDelete.id));

      // Close the modal after deletion
      setDeleteModalOpen(false);
    } catch (error) {
      console.error('Error deleting booking:', error);
    }
  };

  // Handle Modal Close
  const handleDeleteCancel = () => {
    setDeleteModalOpen(false); // Close the delete modal without doing anything
    setSelectedBookingForDelete(null); // Reset the selected booking for delete
  };

  return (
    <>
      <TitleCard title="Booked Apartments">
        {/* Table to display booked apartments */}
        <table className="min-w-full shadow-md rounded-lg">
          <thead>
            <tr>
              <th className="">Start Date</th>
              <th className="">End Date</th>
              <th className="">Total Price</th>
              <th className="">User</th>
              <th className="">Apartment</th>
              <th className="">Status</th>
              <th className="">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((booking) => (
              <tr key={booking.id}>
                <td className="py-2 px-4 border-b">{new Date(booking.startDate).toLocaleDateString()}</td>
                <td className="py-2 px-4 border-b">{new Date(booking.endDate).toLocaleDateString()}</td>
                <td className="py-2 px-4 border-b">{booking.totalPrice}</td>
                <td className="py-2 px-4 border-b">{booking.User.fullName} ({booking.User.username})</td>
                <td className="py-2 px-4 border-b">{booking.Apartment.title} (Room {booking.Apartment.noRoom})</td>
                
                <td className="py-2 px-4 border-b">
                  <select
                    value={booking.status}
                    onChange={(e) => handleStatusChange(booking.id, e.target.value)}
                    className="p-1 border rounded w-full bg-base-100 text-white"
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </td>

                <td className="py-2 px-4 border-b">
                  <button
                    className="bg-red-500 text-white py-1 px-3 rounded-md hover:bg-red-600 ml-2"
                    onClick={() => handleDelete(booking)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </TitleCard>

      {/* Delete Confirmation Modal */}
      <Modal open={deleteModalOpen} onClose={handleDeleteCancel} center>
        <h2 className="text-xl font-semibold mb-4">Are you sure you want to delete this booking?</h2>
        <div className="flex justify-between">
          <button
            onClick={handleDeleteConfirm}
            className="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600"
          >
            Yes, Delete
          </button>
          <button
            onClick={handleDeleteCancel}
            className="bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600"
          >
            Cancel
          </button>
        </div>
      </Modal>
    </>
  );
};

export default BookedApartmentsPage;
