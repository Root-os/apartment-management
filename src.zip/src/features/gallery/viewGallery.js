import React, { useState, useEffect } from 'react';
import axios from 'axios';


const GalleryDisplay = () => {
  // State hooks to manage galleries and loading
  const [galleries, setGalleries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [categories, setCategories] = useState([]);

  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedGallery, setSelectedGallery] = useState(null);

  const [updatedTitle, setUpdatedTitle] = useState('');
  const [updatedCategoryId, setUpdatedCategoryId] = useState(null);
  const [updatedImage, setUpdatedImage] = useState(null);

  const [modalMessage, setModalMessage] = useState(''); // Modal message
  const [modalMessageType, setModalMessageType] = useState(null); // Modal message type

  const fetchCategories = async () => {
    try {
      const response = await axios.get('https://website.smartbingogames.com/api/category');
      console.log('API Response:', response);  // Log the full response

      // Check if the 'categories' field exists in the response
      if (response.data && response.data.categories) {
        setCategories(response.data.categories);  // Set categories in state
        console.log('Categories fetched:', response.data.categories);  // Log categories
      } else {
        setError('Failed to load categories. Categories not found in the response.');
      }
    } catch (err) {
      setError('Failed to load categories.');
      console.error('Error fetching categories:', err);
    }
  };

  useEffect(() => {
    fetchGalleries();
    fetchCategories();
  }, []);

  const getFullImageUrl = (url) => {
    return url.startsWith('http') ? url : `https://website.smartbingogames.com${url}`;
  };

  const fetchGalleries = async () => {
    try {
      const response = await axios.get('https://website.smartbingogames.com/api/gallery');
      if (response.data.success) {
        setGalleries(response.data.galleries);
        console.log('Fetched categories:', response.data.categories);
      } else {
        setError('Failed to load galleries.');
      }
    } catch (err) {
      setError('Failed to load galleries.');
      console.error('Error fetching galleries:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateGallery = async (e) => {
    e.preventDefault();

    // Create FormData object to handle the file upload
    const formData = new FormData();
    formData.append('title', updatedTitle);
    formData.append('categoryId', String(updatedCategoryId));

    if (updatedImage) {
      formData.append('imageUrl', updatedImage);
    }

    try {
      if (selectedGallery) {
        await axios.put(
          `https://website.smartbingogames.com/api/gallery/${selectedGallery.id}`,
          formData
        );

        fetchGalleries();
        setShowModal(false); // Close the update modal
        setError(''); // Clear any error message
        setModalMessage('Gallery updated successfully!');
        setModalMessageType('success');
      }
    } catch (err) {
      setError('Failed to update gallery.');
      setModalMessage('Failed to update gallery.');
      setModalMessageType('error');
    }
  };

  // Handle the category change in the dropdown
  const handleCategoryChange = (e) => {
    setUpdatedCategoryId(Number(e.target.value));
  };

  // Handle the file change (image upload)
  const handleImageChange = (e) => {
    if (e.target.files) {
      setUpdatedImage(e.target.files[0]); // Set the selected image file
    }
  };

  const handleUpdateClick = (gallery) => {
    // Set the selected gallery in the state to pre-fill the modal with current data
    setSelectedGallery(gallery);
    setUpdatedTitle(gallery.title); // Pre-fill title in the modal
    setUpdatedCategoryId(gallery.categoryId); // Pre-fill categoryId
    setUpdatedImage(null); // Clear any previous image selection
    setShowModal(true); // Open the update modal
  };

  // Delete gallery
  const deleteGallery = async () => {
    if (selectedGallery) {
      try {
        await axios.delete(`https://website.smartbingogames.com/api/gallery/${selectedGallery.id}`);
        fetchGalleries(); // Reload galleries
        setShowDeleteConfirm(false); // Close delete confirm
        setError(''); // Clear error after success
        setModalMessage('Gallery deleted successfully!');
        setModalMessageType('success');
      } catch (err) {
        setError('Failed to delete gallery.');
        setModalMessage('Failed to delete gallery.');
        setModalMessageType('error');
      }
    }
  };

  const handleDeleteClick = (gallery) => {
    setSelectedGallery(gallery);
    setShowDeleteConfirm(true);
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <h2 className="text-xl font-semibold text-center mb-4">Gallery</h2>

     
        <>
          {error && <div className="bg-red-500 text-white p-4 rounded mb-4">{error}</div>}

          {/* Gallery Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {galleries.map((gallery) => (
              <div key={gallery.id} className="bg-white p-4 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300">
                <img
                  src={getFullImageUrl(gallery.imageUrl)} // Use the full image URL here
                  alt={gallery.title}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <div className="text-center">
                  <h3 className="font-semibold text-lg">{gallery.title}</h3>
                  <p className="text-sm text-gray-600">
                    {gallery.category ? gallery.category.name : 'Uncategorized'}
                  </p>
                  {/* Action Buttons */}
                  <div className="flex justify-center mt-4 space-x-2">
                    <button onClick={() => handleUpdateClick(gallery)}
                        className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                      Update
                    </button>
                    <button onClick={() => handleDeleteClick(gallery)} 
                       className="mt-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 ml-4">
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
     
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h3 className="text-lg mb-4">Update Gallery</h3>
            <form onSubmit={handleUpdateGallery}>
              <div className="mb-4">
                <label className="block text-sm font-semibold">Title</label>
                <input
                  type="text"
                  value={updatedTitle}
                  onChange={(e) => setUpdatedTitle(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-semibold">Category</label>
                <select
                  value={updatedCategoryId || ''} // this ensures the selected category is correctly set
                  onChange={handleCategoryChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="">Select Category</option>
                  {categories && categories.length > 0 ? (
                    categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))
                  ) : (
                    <option disabled>No categories available</option>
                  )}
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-semibold">Image</label>
                <input
                  type="file"
                  onChange={handleImageChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
              </div>

              <div className="flex justify-end space-x-4">
                <button type="submit" className="bg-blue-500 text-white p-2 rounded-md">
                  Update
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="bg-gray-500 text-white p-2 rounded-md"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h3 className="text-lg text-black mb-4">Do you want to delete this gallery?</h3>
            <div className="flex justify-end space-x-4">
              <button
                onClick={deleteGallery}
                className="bg-red-500 text-white p-2 rounded-md"
              >
                Yes
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GalleryDisplay;
