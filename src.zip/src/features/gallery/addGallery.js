import { useState, useEffect } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText';
import TitleCard from '../../components/Cards/TitleCard'

function GalleryInsert() {
    const INITIAL_GALLERY_OBJ = {
        title: "",
        image: null,
        categoryId: "",
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [galleryObj, setGalleryObj] = useState(INITIAL_GALLERY_OBJ);
    const [categories, setCategories] = useState([]);

    // Fetch categories from the API
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get("https://website.smartbingogames.com/api/category");
                setCategories(response.data.categories);
            } catch (error) {
                setErrorMessage("Failed to fetch categories.");
            }
        };

        fetchCategories();
    }, []);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for empty fields
        if (galleryObj.title.trim() === "")
            return setErrorMessage("Title is required.");
        if (!galleryObj.image)
            return setErrorMessage("Image is required.");
        if (galleryObj.categoryId.trim() === "")
            return setErrorMessage("Category is required.");

        try {
            setLoading(true);
            
            // Prepare form data for the API request
            const formData = new FormData();
            formData.append("title", galleryObj.title);
            formData.append("imageUrl", galleryObj.image);  // Assuming the image is a file
            formData.append("categoryId", galleryObj.categoryId);

            // Make the API request to insert the gallery item
            const response = await axios.post("https://website.smartbingogames.com/api/gallery", formData);

            if (response.data.id) {
                window.location.href = '/app/gallery-view';  // Redirect to the gallery view
            } else {
                setErrorMessage("Failed to create gallery.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setGalleryObj({ ...galleryObj, [updateType]: value });
    };

    return (
        <>
        <TitleCard title="Add Image" topMargin=""mt-6>
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Title</label>
                                    <input
                                        type="text"
                                        value={galleryObj.title}
                                        onChange={(e) => updateFormValue({ updateType: "title", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Category</label>
                                    <select
                                        value={galleryObj.categoryId}
                                        onChange={(e) => updateFormValue({ updateType: "categoryId", value: e.target.value })}
                                        className="select select-bordered w-full"
                                    >
                                        <option value="" disabled>Select a Category</option>
                                        {categories.map((category) => (
                                            <option key={category.id} value={category.id}>
                                                {category.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Image</label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => updateFormValue({ updateType: "image", value: e.target.files[0] })}
                                        className="file-input file-input-bordered w-full"
                                    />
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Gallery
                            </button>
                        </form>
                        </TitleCard>
          </>
    );
}

export default GalleryInsert;
