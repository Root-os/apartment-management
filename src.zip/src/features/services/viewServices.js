import { useState, useEffect } from "react";
import axios from "axios";
import { Modal } from "react-responsive-modal";  
import 'react-responsive-modal/styles.css';
import TitleCard from '../../components/Cards/TitleCard';

const ServicePage = () => {
  const [services, setServices] = useState([]);
  const [categories, setCategories] = useState([]);  // To store categories
  const [searchText, setSearchText] = useState("");
  const [sortedServices, setSortedServices] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5); // Default rows per page
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [currentService, setCurrentService] = useState(null);
  const [newImage, setNewImage] = useState(null);

  // Fetch the services data
  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get("https://website.smartbingogames.com/api/service");
        setServices(response.data.services);
        setSortedServices(response.data.services);  // Initially, no sorting
      } catch (error) {
        console.error("Error fetching services:", error);
      }
    };

    const fetchCategories = async () => {
      try {
        const response = await axios.get("https://website.smartbingogames.com/api/category");
        setCategories(response.data);  // Set categories
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };

    fetchServices();
    fetchCategories();  // Fetch categories on component mount
  }, []);

  // Search filtering
  useEffect(() => {
    const filteredServices = services.filter(service =>
      service.title.toLowerCase().includes(searchText.toLowerCase()) ||
      service.category.toLowerCase().includes(searchText.toLowerCase())
    );
    setSortedServices(filteredServices);
  }, [searchText, services]);

  // Pagination Logic
  const indexOfLastService = currentPage * rowsPerPage;
  const indexOfFirstService = indexOfLastService - rowsPerPage;
  const currentServices = sortedServices.slice(indexOfFirstService, indexOfLastService);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Sorting Logic
  const sortData = (column) => {
    const sorted = [...sortedServices].sort((a, b) => {
      if (a[column] < b[column]) return -1;
      if (a[column] > b[column]) return 1;
      return 0;
    });
    setSortedServices(sorted);
  };

  // Open edit modal
  const openEditModal = (service) => {
    setCurrentService(service);
    setNewImage(null);  // Reset image preview on open
    setIsEditModalOpen(true);
  };

  // Open delete modal
  const openDeleteModal = (service) => {
    setCurrentService(service);
    setIsDeleteModalOpen(true);
  };

  // Open detail modal
  const openDetailModal = (service) => {
    setCurrentService(service);
    setIsDetailModalOpen(true);
  };

  // Close all modals
  const closeModals = () => {
    setIsEditModalOpen(false);
    setIsDeleteModalOpen(false);
    setIsDetailModalOpen(false);
    setCurrentService(null);
    setNewImage(null); // Reset image preview
  };

  // Handle service edit
  const handleEditService = () => {
    if (currentService) {
      const updatedService = new FormData();
      
      // Append existing data to FormData
      updatedService.append("title", currentService.title);
      updatedService.append("category", currentService.category);
      updatedService.append("time", currentService.time);
      updatedService.append("pricing", currentService.pricing || '');  // If pricing exists, otherwise add empty string

      // If a new image is selected, append it to FormData
      if (newImage) {
        updatedService.append("image", newImage); // Append new image if selected
      }

      // Send the data to the backend
      axios
        .put(`https://website.smartbingogames.com/api/service/${currentService.id}`, updatedService, {
          headers: {
            "Content-Type": "multipart/form-data", // Important for sending files
          },
        })
        .then((response) => {
          // Update the service list with the new image URL (if returned)
          setServices((prevServices) =>
            prevServices.map((service) =>
              service.id === currentService.id
                ? { ...service, title: currentService.title, category: currentService.category, time: currentService.time, image: response.data.image } // Assuming 'image' field contains the URL
                : service
            )
          );
          closeModals();  // Close the modal
          setNewImage(null); // Reset the image input
        })
        .catch((error) => {
          console.error("Error updating service:", error);
        });
    }
  };

  // Handle delete service
  const handleDeleteService = async () => {
    try {
      await axios.delete(`https://website.smartbingogames.com/api/service/${currentService.id}`);
      // After delete, remove from list
      setServices(services.filter(service => service.id !== currentService.id));
      closeModals();
    } catch (error) {
      console.error("Error deleting service:", error);
    }
  };

  // Handle image file change (preview and file upload)
  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setNewImage(file); // Set the selected image file to the state
    }
  };

  return (
    <>
      <TitleCard title="Services" topMargin="mt-6">
        <div className="overflow-x-auto w-full">
          <table className="table w-full table-zebra">
            <thead>
              <tr>
                <th onClick={() => sortData("title")} className="cursor-pointer">Title</th>
                <th onClick={() => sortData("category")} className="cursor-pointer">Category</th>
                <th onClick={() => sortData("time")} className="cursor-pointer">Time</th>
                <th>Image</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentServices.map(service => (
                <tr key={service.id}>
                  <td>{service.title}</td>
                  <td>{service.category}</td>
                  <td>{service.time}</td>
                  <td>
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-16 h-16 object-cover rounded"
                    />
                  </td>
                  <td>
                    <div className="dropdown dropdown-bottom dropdown-end">
                      <button tabIndex={0} className="btn btn-sm btn-outline">Actions</button>
                      <ul tabIndex={0} className="dropdown-content menu p-2 text-sm shadow bg-base-100 rounded-box w-52">
                        <li>
                          <button onClick={() => openDetailModal(service)} className="btn btn-xs">Details</button>
                        </li>
                        <li>
                          <button onClick={() => openEditModal(service)} className="btn btn-xs">Edit</button>
                        </li>
                        <li>
                          <button onClick={() => openDeleteModal(service)} className="btn btn-xs text-red-600">Delete</button>
                        </li>
                      </ul>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="mt-4 flex justify-center">
          <button
            onClick={() => paginate(currentPage - 1)}
            disabled={currentPage === 1}
            className="btn btn-primary mx-2">
            Prev
          </button>
          <span className="text-lg">
            Page {currentPage} of {Math.ceil(sortedServices.length / rowsPerPage)}
          </span>
          <button
            onClick={() => paginate(currentPage + 1)}
            disabled={currentPage === Math.ceil(sortedServices.length / rowsPerPage)}
            className="btn btn-primary mx-2">
            Next
          </button>
        </div>

        {/* Edit Modal */}
        <Modal open={isEditModalOpen} onClose={closeModals} center>
          <h2>Edit Service</h2>
          {currentService && (
            <div>
              <label>Title</label>
              <input
                type="text"
                value={currentService.title}
                onChange={(e) => setCurrentService({ ...currentService, title: e.target.value })}
                className="input input-bordered mb-4 w-full"
              />

              <label>Category</label>
              <select
                value={currentService.category}
                onChange={(e) => setCurrentService({ ...currentService, category: e.target.value })}
                className="select select-bordered mb-4 w-full"
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.name}>
                    {category.name}
                  </option>
                ))}
              </select>

              <label>Time</label>
              <input
                type="text"
                value={currentService.time}
                onChange={(e) => setCurrentService({ ...currentService, time: e.target.value })}
                className="input input-bordered mb-4 w-full"
              />

              <label>Pricing</label>
              <input
                type="text"
                value={currentService.pricing || ''}
                onChange={(e) => setCurrentService({ ...currentService, pricing: e.target.value })}
                className="input input-bordered mb-4 w-full"
              />

              <label>Image</label>
              <input
                type="file"
                onChange={handleImageChange}
                className="file-input file-input-bordered w-full mb-4"
              />
              {newImage && (
                <div className="mt-2">
                  <img
                    src={URL.createObjectURL(newImage)}
                    alt="Selected"
                    className="w-32 h-32 object-cover"
                  />
                </div>
              )}

              <label>Description</label>
              <textarea
                value={currentService.description}
                onChange={(e) => setCurrentService({ ...currentService, description: e.target.value })}
                className="textarea textarea-bordered mb-4 w-full"
              ></textarea>

              <button onClick={handleEditService} className="btn btn-primary">Save Changes</button>
            </div>
          )}
        </Modal>

        {/* Delete Modal */}
        <Modal open={isDeleteModalOpen} onClose={closeModals} center>
          <h2>Are you sure you want to delete this service?</h2>
          <button onClick={handleDeleteService} className="btn btn-error">Delete</button>
          <button onClick={closeModals} className="btn btn-secondary">Cancel</button>
        </Modal>

        {/* Detail Modal */}
        <Modal open={isDetailModalOpen} onClose={closeModals} center>
          <h2>Service Details</h2>
          {currentService && (
            <div>
              <p><strong>Title:</strong> {currentService.title}</p>
              <p><strong>Category:</strong> {currentService.category}</p>
              <p><strong>Time:</strong> {currentService.time}</p>
              <p><strong>Description:</strong> {currentService.description}</p>
              <p><strong>Pricing:</strong> {currentService.pricing}</p>
              <div>
                <strong>Image:</strong>
                <img
                  src={currentService.image}
                  alt={currentService.title}
                  className="w-32 h-32 object-cover mt-2"
                />
              </div>
            </div>
          )}
        </Modal>
      </TitleCard>
    </>
  );
};

export default ServicePage;
