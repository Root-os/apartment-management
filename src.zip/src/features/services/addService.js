import { useState, useEffect } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText'; 
import TitleCard from '../../components/Cards/TitleCard';
function ServiceInsert() {
    const INITIAL_SERVICE_OBJ = {
        title: "",
        description: "",
        category: "",
        time: "",
        pricing: "",
        image: null,
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [serviceObj, setServiceObj] = useState(INITIAL_SERVICE_OBJ);
    const [categories, setCategories] = useState([]); // For categories dropdown
    const [categoriesLoaded, setCategoriesLoaded] = useState(false); // Track if categories are loaded

    // Fetch categories to populate the dropdown
    const fetchCategories = async () => {
        try {
            const response = await axios.get('https://website.smartbingogames.com/api/category');
            if (response.data && Array.isArray(response.data.categories)) {
                setCategories(response.data.categories); // Access the categories array from the response
                setCategoriesLoaded(true);
            } else {
                console.error('API response structure is unexpected:', response);
                setErrorMessage('Failed to load categories.');
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
            setErrorMessage('Failed to load categories.');
        }
    };

    // Call fetchCategories when the component mounts
    useEffect(() => {
        fetchCategories();
    }, []);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validate form fields
        if (serviceObj.title.trim() === "") return setErrorMessage("Title is required.");
        if (serviceObj.description.trim() === "") return setErrorMessage("Description is required.");
        if (serviceObj.category.trim() === "") return setErrorMessage("Category is required.");
        if (serviceObj.time.trim() === "") return setErrorMessage("Time is required.");
        if (serviceObj.pricing.trim() === "") return setErrorMessage("Pricing is required.");
        if (!serviceObj.image) return setErrorMessage("Image is required.");

        try {
            setLoading(true);

            // Prepare form data for API request
            const formData = new FormData();
            formData.append("title", serviceObj.title);
            formData.append("description", serviceObj.description);
            formData.append("category", serviceObj.category);
            formData.append("time", serviceObj.time);
            formData.append("pricing", serviceObj.pricing);
            formData.append("image", serviceObj.image); // The file to be uploaded

            // Make the API request to insert the service
            const response = await axios.post("https://website.smartbingogames.com/api/service", formData, {
                headers: {
                    "Content-Type": "multipart/form-data", // Important for file uploads
                },
            });

            // Handle the success response
            if (response.data.message === "Service created successfully") {
                alert("Service created successfully!");
                // You can reset the form or do other things after success
                setServiceObj(INITIAL_SERVICE_OBJ);
            } else {
                setErrorMessage("Failed to create service.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setServiceObj({ ...serviceObj, [updateType]: value });
    };

    return (
        <>
        <TitleCard title="Add Service" topMargin="mt-6">
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                {/* Title Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Title</label>
                                    <input
                                        type="text"
                                        value={serviceObj.title}
                                        onChange={(e) => updateFormValue({ updateType: "title", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Description Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Description</label>
                                    <textarea
                                        value={serviceObj.description}
                                        onChange={(e) => updateFormValue({ updateType: "description", value: e.target.value })}
                                        className="textarea textarea-bordered w-full"
                                    ></textarea>
                                </div>

                                {/* Category Dropdown */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Category</label>
                                    <select
                                        value={serviceObj.category}
                                        onChange={(e) => updateFormValue({ updateType: "category", value: e.target.value })}
                                        className="select select-bordered w-full"
                                    >
                                        <option value="">Select Category</option>
                                        {categoriesLoaded ? (
                                            categories.map((category) => (
                                                <option key={category.id} value={category.name}>
                                                    {category.name}
                                                </option>
                                            ))
                                        ) : (
                                            <option disabled>Loading categories...</option>
                                        )}
                                    </select>
                                </div>

                                {/* Time Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Time</label>
                                    <input
                                        type="text"
                                        value={serviceObj.time}
                                        onChange={(e) => updateFormValue({ updateType: "time", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Pricing Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Pricing</label>
                                    <input
                                        type="text"
                                        value={serviceObj.pricing}
                                        onChange={(e) => updateFormValue({ updateType: "pricing", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Image Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Image</label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => updateFormValue({ updateType: "image", value: e.target.files[0] })}
                                        className="file-input file-input-bordered w-full"
                                    />
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Service
                            </button>
                        </form>
                    </TitleCard>
           </>
    );
}

export default ServiceInsert;
