import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TitleCard from '../../components/Cards/TitleCard'

const AboutPage = () => {
  const [aboutData, setAboutData] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editedAboutData, setEditedAboutData] = useState(null); // For holding edited data

  // Fetch About Us data
  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const response = await axios.get('https://website.smartbingogames.com/api/about');
        setAboutData(response.data.data[0]); // Assuming there's only one "about" entry
        setEditedAboutData(response.data.data[0]); // Initialize with fetched data
      } catch (error) {
        console.error('Error fetching about data:', error);
      }
    };

    fetchAboutData();
  }, []);

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditedAboutData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleEditSubmit = async () => {
    try {
      await axios.put(`https://website.smartbingogames.com/api/about/${aboutData.id}`, editedAboutData);
      setAboutData(editedAboutData); // Update displayed data after edit
      setShowEditModal(false); // Close modal
    } catch (error) {
      console.error('Error updating about data:', error);
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`https://website.smartbingogames.com/api/about/${aboutData.id}`);
      setAboutData(null); // Remove deleted data from the state
      setShowDeleteModal(false); // Close the delete modal
    } catch (error) {
      console.error('Error deleting about data:', error);
    }
  };

  if (!aboutData) {
    return <div className="text-center py-6">Loading...</div>;
  }

  const socialMediaLinks = JSON.parse(aboutData.socialMediaLinks); // Parse social media links from stringified JSON

  return (
    <><TitleCard title="About Us" topMargin=""mt-6>

      {/* Company Information */}
      <div className=" shadow-lg rounded-lg p-6 mb-6">
        <h3 className="text-2xl font-semibold text-white-800">{aboutData.companyName}</h3>
        <p className="text-lg text-white-600 mt-2">{aboutData.companyDescription}</p>
        <h4 className="text-xl font-semibold text-white-800 mt-6">Vision Statement</h4>
        <p className="text-lg text-white-600">{aboutData.visionStatement}</p>
        <h4 className="text-xl font-semibold text-white-800 mt-6">Vision Motto</h4>
        <p className="text-lg text-white-600">{aboutData.visionMotto}</p>
        <h3 className="text-xl font-semibold text-white-800">Contact Information</h3>
        <p className="text-lg text-white-600 mt-2"><strong>Phone:</strong> {aboutData.phoneNumber}</p>
        <p className="text-lg text-white-600"><strong>Email:</strong> <a href={`mailto:${aboutData.email}`} className="text-blue-500">{aboutData.email}</a></p>
        <p className="text-lg text-white-600"><strong>Address:</strong> {aboutData.address}</p>
        <h3 className="text-xl font-semibold text-white-800">Follow Us</h3>
        <div className="flex space-x-4 mt-4">
          {socialMediaLinks.facebook && (
            <a href={socialMediaLinks.facebook} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">
              Facebook
            </a>
          )}
          {socialMediaLinks.twitter && (
            <a href={socialMediaLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-600">
              Twitter
            </a>
          )}
          {socialMediaLinks.linkedin && (
            <a href={socialMediaLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-blue-700 hover:text-blue-900">
              LinkedIn
            </a>
          )}
        </div>

        {/* Edit and Delete Buttons */}
        <div className="flex justify-end mt-6">
          <button
            className="btn btn-primary mr-4"
            onClick={() => setShowEditModal(true)}
          >
            Edit
          </button>
          <button
            className="btn btn-danger"
            onClick={() => setShowDeleteModal(true)}
          >
            Delete
          </button>
        </div>
      </div>

      {/* Edit Modal */}
      {showEditModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="modal modal-open">
            <div className="modal-box  p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-bold">Edit About Us Information</h2>
              <div className="form-control mt-4">
                <label className="label">Company Name</label>
                <input
                  type="text"
                  className="input  bg-white-100"
                  name="companyName"
                  value={editedAboutData.companyName}
                  onChange={handleEditChange}
                />
              </div>
              <div className="form-control mt-4">
                <label className="label">Company Description</label>
                <textarea
                  className="textarea textarea-bordered"
                  name="companyDescription"
                  value={editedAboutData.companyDescription}
                  onChange={handleEditChange}
                />
              </div>
              <div className="modal-action">
                <button className="btn btn-primary" onClick={handleEditSubmit}>
                  Save Changes
                </button>
                <button className="btn btn-ghost" onClick={() => setShowEditModal(false)}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="modal modal-open">
            <div className="modal-box  p-6 rounded-lg shadow-lg">
              <h2 className="text-lg font-bold ">Are you sure you want to delete this information?</h2>
              <div className="modal-action">
                <button className="btn btn-error" onClick={handleDelete}>
                  Yes, Delete
                </button>
                <button className="btn btn-ghost" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </TitleCard>
    </>
  );
};

export default AboutPage;
