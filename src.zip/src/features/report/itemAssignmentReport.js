import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TableComponent from '../../components/table';
import Modal from '../../components/Modal';
import LoadingComponent from '../../components/loading';

const ItemAssignmentReport = () => {
  const [itemAssignments, setItemAssignments] = useState([]); // Store item assignments data
  const [items, setItems] = useState([]); // Store items fetched from API
  const [filterParams, setFilterParams] = useState({
    assignType: 'user', // Default filter
    assignDate: '', // Optional filter for assignment date
    itemId: '', // Optional filter for item ID
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  // Fetch items data
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_BASE_URL}items`);
        setItems(response.data); // Store items in state
      } catch (error) {
        console.error('Error fetching items:', error);
      } finally {setLoading(false);}
    };
    fetchItems();
  }, []);

  // Fetch item assignments data based on filters
  const handleFilterSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true); // Start loading

    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_URL}item-assignments/report`,
        filterParams
      );
      console.log('API response:', response.data);

      // Update the state with the received data
      setItemAssignments(response.data);
    } catch (error) {
      const message =
        error.response?.status === 404
          ? 'No item assignments found with the given filters.'
          : 'Error filtering data. Please try again.';
      setModalMessage(message);
      setIsModalOpen(true);
      console.error('Error filtering data:', error);
    } finally {
      setIsLoading(false); // Stop loading
    }
  };

  // Define columns for the table
  const columns = [
    { key: 'itemName', label: 'Item Name' },
    { key: 'assignedTo', label: 'Assigned To' },
    { key: 'assignDate', label: 'Assignment Date', render: (data) => new Date(data.assignDate).toLocaleDateString() },
    { key: 'assignType', label: 'Assignment Type' },
  ];

  return (
    <div className="p-8">
      <div className="container mx-auto p-4">
        <h2 className="text-2xl font-bold mb-6">Item Assignment Report</h2>

        {/* Filter Form */}
        <form onSubmit={handleFilterSubmit} className="grid grid-cols-4 gap-4">
          {/* Assign Type */}
          <div>
            <label htmlFor="assignType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Assignment Type
            </label>
            <select
              id="assignType"
              className="w-full p-2 border border-gray-300 rounded dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
              value={filterParams.assignType}
              onChange={(e) => setFilterParams({ ...filterParams, assignType: e.target.value })}
            >
              <option value="user">User</option>
              <option value="tenant">Tenant</option>
              <option value="staff">Staff</option>
              {/* You can add more options based on the possible assignment types */}
            </select>
          </div>

          {/* Assign Date */}
          <div>
            <label htmlFor="assignDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Assign Date
            </label>
            <input
              type="date"
              id="assignDate"
              className="w-full p-2 border border-gray-300 rounded dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
              value={filterParams.assignDate}
              onChange={(e) => setFilterParams({ ...filterParams, assignDate: e.target.value })}
            />
          </div>

          {/* Item ID (Dynamic dropdown populated from API) */}
          <div>
            <label htmlFor="itemId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Item Name (Optional)
            </label>
            <select
              id="itemId"
              className="w-full p-2 border border-gray-300 rounded dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
              value={filterParams.itemId}
              onChange={(e) => setFilterParams({ ...filterParams, itemId: e.target.value })}
            >
              <option value="">Select Item</option>
              {items.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.itemName}
                </option>
              ))}
            </select>
          </div>

          {/* Submit Button */}
          <div className="col-span-4 flex justify-end">
            <button
              type="submit"
              className="w-40 bg-blue-500 text-white p-2 rounded hover:bg-blue-700 dark:bg-blue-700 dark:text-gray-300"
            >
              {isLoading ? 'Processing...' : 'Filter Data'}
            </button>
          </div>
        </form>
      </div>

      {/* Table for displaying item assignments report */}
      {loading ? (<LoadingComponent/>):(
      <TableComponent
        title="Filtered Item Assignment Report"
        data={itemAssignments || []}
        columns={columns}
        rowsPerPageOptions={[5, 10, 15]}
        showSearch={true}
        exportable={true}
      />
      )}
      {/* Modal for displaying error message */}
      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          type="error"
          message={modalMessage}
        />
      )}
    </div>
  );
};

export default ItemAssignmentReport;
