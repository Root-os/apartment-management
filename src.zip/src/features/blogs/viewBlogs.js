import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TitleCard from '../../components/Cards/TitleCard'

const BlogPage = () => {
  const [blogs, setBlogs] = useState([]);
  const [categories, setCategories] = useState([]); // State for categories
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingBlog, setEditingBlog] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [blogToDelete, setBlogToDelete] = useState(null);
  const [alert, setAlert] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(5);

  useEffect(() => {
    const fetchBlogsAndCategories = async () => {
      try {
        const blogResponse = await axios.get('https://website.smartbingogames.com/api/blogs');
        const categoryResponse = await axios.get('https://website.smartbingogames.com/api/category');
        if (blogResponse.data && Array.isArray(blogResponse.data.blogs)) {
          setBlogs(blogResponse.data.blogs);
        } else {
          setError('The blogs data is not in the expected format.');
        }
        if (categoryResponse.data && Array.isArray(categoryResponse.data.categories)) {
          setCategories(categoryResponse.data.categories);  // Set categories
        } else {
          setError('The categories data is not in the expected format.');
        }
        setLoading(false);
      } catch (error) {
        setError('Failed to fetch blogs or categories.');
        setLoading(false);
      }
    };

    fetchBlogsAndCategories();
  }, []);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1); // Reset to page 1 on search change
  };

  const filteredBlogs = blogs.filter((blog) =>
    blog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    blog.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentBlogs = filteredBlogs.slice(indexOfFirstPost, indexOfLastPost);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < Math.ceil(filteredBlogs.length / postsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleRowsPerPageChange = (e) => {
    setPostsPerPage(Number(e.target.value));
    setCurrentPage(1); // Reset to page 1 when changing rows per page
  };

  if (error) {
    return <div className="text-center text-xl text-red-500">{error}</div>;
  }

  const handleInputChange = (e) => {
    if (editingBlog) {
      setEditingBlog({
        ...editingBlog,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handleCategoryChange = (e) => {
    if (editingBlog) {
      setEditingBlog({
        ...editingBlog,
        category: e.target.value, // Update the category
      });
    }
  };

  const handleDateChange = (e) => {
    if (editingBlog) {
      setEditingBlog({
        ...editingBlog,
        date: e.target.value, // Update the date
      });
    }
  };

  const handleImageChange = async (e) => {
    if (e.target.files && e.target.files[0]) {
      const formData = new FormData();
      formData.append('image', e.target.files[0]);
  
      try {
        // PUT request to update the image for the specific blog
        if (editingBlog) {
          const response = await axios.put(
            `https://website.smartbingogames.com/api/blogs/${editingBlog.id}`,
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data',
              },
            }
          );
  
          // Update the blog with the new image URL
          if (response.data && response.data.image) {
            setEditingBlog({
              ...editingBlog,
              image: response.data.image, // Assuming the response contains the image URL
            });
          }
        }
      } catch (error) {
        console.error('Error uploading image:', error);
        setAlert({ message: 'Failed to upload image.', type: 'error' });
      }
    }
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editingBlog) {
      try {
        await axios.put(`https://website.smartbingogames.com/api/blogs/${editingBlog.id}`, {
          title: editingBlog.title,
          description: editingBlog.description,
          category: editingBlog.category,
          date: editingBlog.date, // Send the updated date
          image: editingBlog.image, // Ensure image URL is included in the update
        });

        setIsModalOpen(false);
        setLoading(true);
        const response = await axios.get('https://website.smartbingogames.com/api/blogs');
        setBlogs(response.data.blogs);
        setLoading(false);

        setAlert({ message: 'Blog updated successfully!', type: 'success' });
      } catch (error) {
        console.error('Error updating blog:', error);
        setAlert({ message: 'Error updating blog.', type: 'error' });
      }
    }
  };

  const openEditModal = (blog) => {
    setEditingBlog(blog);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingBlog(null);
  };

  const openDeleteModal = (blog) => {
    setBlogToDelete(blog);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (blogToDelete) {
      try {
        await axios.delete(`https://website.smartbingogames.com/api/blogs/${blogToDelete.id}`);
        setBlogs(blogs.filter((blog) => blog.id !== blogToDelete.id));
        setIsDeleteModalOpen(false);
        setBlogToDelete(null);

        setAlert({ message: 'Blog deleted successfully!', type: 'success' });
      } catch (error) {
        console.error('Error deleting blog:', error);
        setAlert({ message: 'Error deleting blog.', type: 'error' });
      }
    }
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setBlogToDelete(null);
  };

  return (
    <><TitleCard title="About Us" topMargin=""mt-6>
     
      {/* Search Bar */}
      <div className="mb-4 flex">
        <input
          type="text"
          value={searchQuery}
          onChange={handleSearchChange}
          placeholder="Search blogs..."
          className="input input-bordered w-full"
        />
      </div>

     
        <div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentBlogs.map((blog) => (
              <div key={blog.id} className="bg-base-200 shadow-lg rounded-lg overflow-hidden transform hover:scale-105 hover:shadow-2xl transition-all duration-300 ease-in-out">
                <div className="relative">
                  {blog.image ? (
                    <img
                      src={blog.image}
                      alt={blog.title}
                      className="w-full h-48 object-cover transition-all duration-300 ease-in-out transform hover:scale-105 hover:opacity-80"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gray-200 flex items-center justify-center text-white-500 text-lg">
                      <img
                        src="/default-image.jpg" // Default image for missing images
                        alt="No Image Available"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <h2 className="text-2xl font-semibold text-white-800 hover:text-blue-600 transition-all duration-200">
                    {blog.title}
                  </h2>
                  <p className="text-sm text-White-500 mb-2">{blog.category}</p>
                  <p className="text-white-700 mb-4 line-clamp-3">{blog.description}</p>
                  <div className="text-sm text-white-500">
                    <p><strong>Date:</strong> {new Date(blog.date).toLocaleDateString()}</p>
                  </div>

                  <button
                    onClick={() => openEditModal(blog)}
                    className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => openDeleteModal(blog)}
                    className="mt-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 ml-4"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          <div className="mt-4 flex justify-between items-center">
            <div className="flex items-center">
              <span className="mr-2"></span>
              <select
                value={postsPerPage}
                onChange={handleRowsPerPageChange}
                className="p-2 border rounded-md"
              >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={20}>20</option>
              </select>
            </div>

            <div className="flex items-center">
              <button
                onClick={handlePrevious}
                disabled={currentPage === 1}
                className="p-2 border rounded-md mr-2 bg-blue-500 text-grey-700"
              >
                &lt;
              </button>
              <span>{currentPage}</span>
              <button
                onClick={handleNext}
                disabled={currentPage === Math.ceil(filteredBlogs.length / postsPerPage)}
                className="p-2 border rounded-md ml-2 bg-blue-500 text-grey-700"
              >
                &gt;
              </button>
            </div>
          </div>
        </div>
    

      {/* Edit Modal */}
      {isModalOpen && editingBlog && (
        <div className="fixed inset-0  bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-base-300 p-6 rounded-lg shadow-lg w-96 mt-12 max-h-[80vh] overflow-y-auto">
            <h2 className="text-3xl font-semibold mb-4">Edit Blog</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="title" className="block text-lg font-semibold text-white-700">Title</label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={editingBlog?.title || ''}
                  onChange={handleInputChange}
                  className="input input-bordered w-full"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="description" className="block text-lg font-semibold text-white-700">Description</label>
                <textarea
                  id="description"
                  name="description"
                  value={editingBlog?.description || ''}
                  onChange={handleInputChange}
                  className="input input-bordered w-full"
                  rows={4}
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="category" className="block text-lg font-semibold text-white-700">Category</label>
                <select
                  id="category"
                  name="category"
                  value={editingBlog?.category || ''}
                  onChange={handleCategoryChange}
                  className="input input-bordered w-full"
                  required
                >
                  <option value="">Select Category</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="mb-4">
                <label htmlFor="date" className="block text-lg font-semibold text-white-700">Date</label>
                <input
                  type="date"
                  id="date"
                  name="date"
                  value={editingBlog?.date || ''}
                  onChange={handleDateChange}
                  className="input input-bordered w-full"
                />
              </div>
              <div className="mb-4">
                <label htmlFor="image" className="block text-lg font-semibold text-gray-700">Upload Image</label>
                <input
                  type="file"
                  id="image"
                  name="image"
                  onChange={handleImageChange}
                  className="w-full p-3 mt-2 border rounded-md"
                />
              </div>
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 bg-gray-300 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded-md"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {isDeleteModalOpen && blogToDelete && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-md shadow-lg max-w-lg w-full">
            <h3 className="text-lg mb-4 text-black">Are you sure you want to delete this blog?</h3>
            <div className="flex justify-end space-x-4">
              <button
                onClick={handleDelete}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
              >
                Yes
              </button>
              <button
                onClick={closeDeleteModal}
                className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400"
              >
                No
              </button>
            </div>
          </div>
        </div>
      )}
   </TitleCard>
  </>
  );
};

export default BlogPage;
