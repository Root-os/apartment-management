import { useState, useEffect } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText'; 
import TitleCard from '../../components/Cards/TitleCard'; 

function BlogInsert() {
    const INITIAL_BLOG_OBJ = {
        title: "",
        description: "",
        date: "",
        category: "",
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [blogObj, setBlogObj] = useState(INITIAL_BLOG_OBJ);
    const [categories, setCategories] = useState([]); // For categories dropdown
    const [categoriesLoaded, setCategoriesLoaded] = useState(false); // Track if categories are loaded

    // Fetch categories to populate the dropdown
    const fetchCategories = async () => {
        try {
            const response = await axios.get('https://website.smartbingogames.com/api/category');
            if (response.data && Array.isArray(response.data.categories)) {
                setCategories(response.data.categories); // Access the categories array from the response
                setCategoriesLoaded(true);
            } else {
                console.error('API response structure is unexpected:', response);
                setErrorMessage('Failed to load categories.');
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
            setErrorMessage('Failed to load categories.');
        }
    };

    // Call fetchCategories when the component mounts
    useEffect(() => {
        fetchCategories();
    }, []);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for form fields
        if (blogObj.title.trim() === "") return setErrorMessage("Title is required.");
        if (blogObj.description.trim() === "") return setErrorMessage("Description is required.");
        if (blogObj.category.trim() === "") return setErrorMessage("Category is required.");
        if (blogObj.date.trim() === "") return setErrorMessage("Date is required.");

        try {
            const response = await axios.post("https://website.smartbingogames.com/api/blogs", blogObj);
            if (response.data.message === "Blog created successfully") {
                alert("Blog created successfully!");
                setBlogObj(INITIAL_BLOG_OBJ);
                window.location.href = '/app/blogs-view'; 
            } else {
                setErrorMessage("Failed to create blog.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setBlogObj({ ...blogObj, [updateType]: value });
    };

    return (
        <div className="min-h-screen bg-base-200 flex items-center">
            <TitleCard title="Add Blog" topMargin="mt-6">
                <form onSubmit={submitForm}>
                    <div className="mb-4">
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-white-700">Title</label>
                            <input
                                type="text"
                                value={blogObj.title}
                                onChange={(e) => updateFormValue({ updateType: "title", value: e.target.value })}
                                className="input input-bordered w-full"
                            />
                        </div>
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-white-700">Description</label>
                            <textarea
                                value={blogObj.description}
                                onChange={(e) => updateFormValue({ updateType: "description", value: e.target.value })}
                                className="textarea textarea-bordered w-full"
                            ></textarea>
                        </div>
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-white-700">Category</label>
                            <select
                                value={blogObj.category}
                                onChange={(e) => updateFormValue({ updateType: "category", value: e.target.value })}
                                className="select select-bordered w-full"
                            >
                                <option value="">Select Category</option>
                                {categoriesLoaded ? (
                                    categories.map((category) => (
                                        <option key={category.id} value={category.name}>
                                            {category.name}
                                        </option>
                                    ))
                                ) : (
                                    <option disabled>Loading categories...</option>
                                )}
                            </select>
                        </div>
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-white-700">Date</label>
                            <input
                                type="date"
                                value={blogObj.date}
                                onChange={(e) => updateFormValue({ updateType: "date", value: e.target.value })}
                                className="input input-bordered w-full"
                            />
                        </div>
                    </div>
                    <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>
                    <button
                        type="submit"
                        className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                        disabled={loading}
                    >
                        Insert Blog
                    </button>
                </form>
            </TitleCard>
        </div>
    );
}

export default BlogInsert;
