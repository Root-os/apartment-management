import React, { useState, useEffect } from 'react';
import axios from 'axios';

const SliderPage = () => {
  const [sliders, setSliders] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedSlider, setSelectedSlider] = useState(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [modalMessage, setModalMessage] = useState('');
  const [modalMessageType, setModalMessageType] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // Fetch sliders data
  const fetchSliders = async () => {
    try {
      const response = await axios.get('https://website.smartbingogames.com/api/slider');
      if (Array.isArray(response.data)) {
        setSliders(response.data);
      } else if (response.data && response.data.sliders) {
        setSliders(response.data.sliders);
      }
    } catch (error) {
      console.error('Error fetching sliders:', error);
      setModalMessage('Error fetching sliders.');
      setModalMessageType('error');
    }
  };

  useEffect(() => {
    fetchSliders();
  }, []);

  // Search filter
  const filteredSliders = sliders.filter((slider) =>
    slider.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredSliders.slice(indexOfFirstItem, indexOfLastItem);

  // Handle page click
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Handle Previous and Next page
  const handlePrevPage = () => setCurrentPage((prev) => Math.max(prev - 1, 1));
  const handleNextPage = () => setCurrentPage((prev) => Math.min(prev + 1, totalPages));

  // Calculate total pages
  const totalPages = Math.ceil(filteredSliders.length / itemsPerPage);

  // Create an array of page numbers for pagination
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }
  const openDetailModal = (slider) => {
    setSelectedSlider(slider);
    setShowDetailModal(true);
  };
  const closeDetailModal = () => setShowDetailModal(false);

  // Open update modal
  const openUpdateModal = (slider) => {
    setSelectedSlider(slider);
    setShowUpdateModal(true);
  };

  // Open delete modal
  const openDeleteModal = (id) => {
    setDeleteId(id);
    setShowDeleteModal(true);
  };

  // Handle update
  const handleUpdate = async () => {
    if (selectedSlider) {
      if (!selectedSlider.title || !selectedSlider.description) {
        return; // Add validation to ensure fields are filled
      }

      try {
        const formData = new FormData();
        formData.append('title', selectedSlider.title);
        formData.append('description', selectedSlider.description);
        if (selectedSlider.image instanceof File) {
          formData.append('image', selectedSlider.image);
        }

        await axios.put(`https://website.smartbingogames.com/api/slider/${selectedSlider.id}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        setShowUpdateModal(false);
        fetchSliders(); // Refresh the list after update
        setModalMessage('Slider updated successfully!');
        setModalMessageType('success');
      } catch (error) {
        console.error('Error updating slider:', error);
        setModalMessage('Error updating slider.');
        setModalMessageType('error');
      }
    }
  };

  // Handle delete
  const handleDelete = async () => {
    if (deleteId) {
      try {
        await axios.delete(`https://website.smartbingogames.com/api/slider/${deleteId}`);
        setShowDeleteModal(false);
        fetchSliders(); // Refresh the list after deletion
        setModalMessage('Slider deleted successfully!');
        setModalMessageType('success');
      } catch (error) {
        console.error('Error deleting slider:', error);
        setModalMessage('Error deleting slider.');
        setModalMessageType('error');
      }
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-semibold text-center">Banners</h2>

      {/* Search Bar */}
      <div className="my-4 flex justify-between items-center">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by title"
          className="px-4 py-2 border border-gray-300 rounded-md w-full max-w-xs"
        />
      </div>

      {/* Cards for displaying sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {currentItems.length > 0 ? (
          currentItems.map((slider) => (
            <div key={slider.id} className="bg-base-300 shadow-lg rounded-lg p-4">
              <h3 className="text-xl font-semibold">{slider.title}</h3>
              {/* <p className="text-gray-700 mt-2">{slider.description}</p> */}
              <img
                src={typeof slider.image === 'string' ? slider.image : URL.createObjectURL(slider.image)}
                alt={slider.title}
                className="mt-4 w-full h-48 object-cover rounded-md"
              />
              <div className="flex justify-between items-center mt-4">
                <button
                  onClick={() => openUpdateModal(slider)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Update
                </button>
                <button
                  onClick={() => openDeleteModal(slider.id)}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Delete
                </button>
                <button
                onClick={() => openDetailModal(slider)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Details
              </button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center text-gray-700 col-span-3">
            No data available
          </div>
        )}
      </div>

      {/* Pagination */}
      <div className="mt-4 flex justify-between items-center">
        <div className="flex items-center">
          <select
            value={itemsPerPage}
            onChange={(e) => setItemsPerPage(Number(e.target.value))}
            className="ml-2 px-2 py-1 border border-gray-300 rounded-md"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={30}>30</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrevPage}
            disabled={currentPage === 1}
            className="px-4 py-2 bg-gray-200 text-gray-600 rounded-md hover:bg-gray-300 disabled:opacity-50"
          >
            &lt;
          </button>

          {pageNumbers.map((number) => (
            <button
              key={number}
              onClick={() => paginate(number)}
              className={`px-4 py-2 rounded-md ${number === currentPage ? 'bg-gray-600 text-white' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}`}
            >
              {number}
            </button>
          ))}

          <button
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className="px-4 py-2 bg-gray-200 text-gray-600 rounded-md hover:bg-gray-300 disabled:opacity-50"
          >
            &gt;
          </button>
        </div>
      </div>

      {/* Modal for Update */}
      {showUpdateModal && selectedSlider && (
        <div className="fixed inset-0  bg-opacity-50 flex items-center justify-center">
          <div className="bg- p-6 rounded-lg shadow-lg w-96">
            <h3 className="text-xl font-semibold mb-4">Update Slider</h3>
            <input
              type="text"
              value={selectedSlider.title}
              onChange={(e) => setSelectedSlider({ ...selectedSlider, title: e.target.value })}
              placeholder="Title"
              className="w-full mb-4 p-2 border border-gray-300 rounded-md"
            />
            <textarea
              value={selectedSlider.description}
              onChange={(e) =>
                setSelectedSlider({ ...selectedSlider, description: e.target.value })
              }
              placeholder="Description"
              className="w-full mb-4 p-2 border border-gray-300 rounded-md"
            />
            <input
              type="file"
              onChange={(e) =>
                e.target.files && setSelectedSlider({ ...selectedSlider, image: e.target.files[0] })
              }
              className="w-full mb-4 p-2 border border-gray-300 rounded-md"
            />
            <div className="flex justify-between">
              <button
                onClick={handleUpdate}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Update
              </button>
              <button
                onClick={() => setShowUpdateModal(false)}
                className="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

{showDetailModal && selectedSlider && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 className="text-xl font-semibold mb-4">Slider Details</h3>
            <h4 className="text-lg font-semibold mb-2">Title: {selectedSlider.title}</h4>
            <p className="text-gray-600 mb-4">Description: {selectedSlider.description}</p>
            <img
              src={typeof selectedSlider.image === 'string' ? selectedSlider.image : URL.createObjectURL(selectedSlider.image)}
              alt={selectedSlider.title}
              className="w-full h-48 object-cover rounded-md mb-4"
            />
            <div className="flex justify-end">
              <button
                onClick={closeDetailModal}
                className="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for Delete */}
      {showDeleteModal && deleteId && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-md shadow-lg max-w-lg w-full">
            <h3 className="text-lg mb-4 text-black">Are you sure you want to delete this slider?</h3>
            <div  className="flex justify-end space-x-4">
              <button
                onClick={handleDelete}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
              >
                Yes
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                 className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SliderPage;
