import { useState } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText';
import TitleCard from '../../components/Cards/TitleCard';

function SliderInsert() {
    const INITIAL_SLIDER_OBJ = {
        title: "",
        description: "",
        image: null,
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [sliderObj, setSliderObj] = useState(INITIAL_SLIDER_OBJ);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for empty fields
        if (sliderObj.title.trim() === "")
            return setErrorMessage("Title is required.");
        if (sliderObj.description.trim() === "")
            return setErrorMessage("Description is required.");
        if (!sliderObj.image)
            return setErrorMessage("Image is required.");

        try {
            setLoading(true);
            
            // Prepare form data for the API request
            const formData = new FormData();
            formData.append("title", sliderObj.title);
            formData.append("description", sliderObj.description);
            formData.append("image", sliderObj.image); 

            // Make the API request to insert the slider
            const response = await axios.post("https://website.smartbingogames.com/api/slider", formData,);
            if (response.data.message === "Slider created successfully") {
                
                window.location.href = '/app/slider-view'; 
            } else {
                setErrorMessage("Failed to create slider.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setSliderObj({ ...sliderObj, [updateType]: value });
    };

    return (
        <>
            <TitleCard title="Add Slider" topMargin="mt-6">
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Title</label>
                                    <input
                                        type="text"
                                        value={sliderObj.title}
                                        onChange={(e) => updateFormValue({ updateType: "title", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Description</label>
                                    <textarea
                                        value={sliderObj.description}
                                        onChange={(e) => updateFormValue({ updateType: "description", value: e.target.value })}
                                        className="textarea textarea-bordered w-full"
                                    ></textarea>
                                </div>
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Image</label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => updateFormValue({ updateType: "image", value: e.target.files[0] })}
                                        className="file-input file-input-bordered w-full"
                                    />
                                </div>
                            </div>

         {/* Error Message */}
         <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Slider
                            </button>
                        </form>
                        </TitleCard>  
        </>
    );
}

export default SliderInsert;
