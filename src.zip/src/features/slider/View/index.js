import { useEffect, useState } from "react";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { showNotification } from "../common/headerSlice";
import TitleCard from "../../components/Cards/TitleCard";
import SearchBar from "../../components/Input/SearchBar";
import { FunnelIcon, XMarkIcon } from '@heroicons/react/24/outline';

const SliderTopSideButtons = ({ applySearch }) => {
    const [searchText, setSearchText] = useState("");

    useEffect(() => {
        if (searchText === "") {
            applySearch("");
        } else {
            applySearch(searchText);
        }
    }, [searchText]);

    return (
        <div className="inline-block float-right">
            <SearchBar searchText={searchText} styleClass="mr-4" setSearchText={setSearchText} />
        </div>
    );
};

function SliderPage() {
    const [sliderData, setSliderData] = useState([]);
    const [filteredSliders, setFilteredSliders] = useState([]);
    const [searchText, setSearchText] = useState("");

    // Simulate an API call
    useEffect(() => {
        fetch("https://website.smartbingogames.com/api/slider")
            .then((response) => response.json())
            .then((data) => {
                setSliderData(data.sliders);
                setFilteredSliders(data.sliders);
            })
            .catch((error) => console.error("Error fetching slider data:", error));
    }, []);

    // Apply search filter
    const applySearch = (value) => {
        setSearchText(value);
        const filtered = sliderData.filter((slider) =>
            slider.title.toLowerCase().includes(value.toLowerCase()) || slider.description.toLowerCase().includes(value.toLowerCase())
        );
        setFilteredSliders(filtered);
    };

    return (
        <>
            <TitleCard title="Sliders" topMargin="mt-2" TopSideButtons={<SliderTopSideButtons applySearch={applySearch} />}>
                {/* Display sliders in a simple list */}
                <div className="overflow-x-auto w-full">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {filteredSliders.map((slider, index) => (
                            <div key={index} className="card w-full bg-base-100 shadow-xl">
                                <figure>
                                    <img src={slider.image} alt={slider.title} />
                                </figure>
                                <div className="card-body">
                                    <h2 className="card-title">{slider.title}</h2>
                                    <p>{slider.description}</p>
                                    <div className="card-actions justify-end">
                                        <button className="btn btn-xs">{moment(slider.createdAt).format("D MMM YYYY")}</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </TitleCard>
        </>
    );
}

export default SliderPage;
