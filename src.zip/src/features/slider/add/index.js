import { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ErrorText from '../../components/Typography/ErrorText'; // Assuming you have ErrorText component for error display

function SliderInsert() {
    const INITIAL_SLIDER_OBJ = {
        title: "",
        description: "",
        image: null,
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [sliderObj, setSliderObj] = useState(INITIAL_SLIDER_OBJ);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for empty fields
        if (sliderObj.title.trim() === "")
            return setErrorMessage("Title is required.");
        if (sliderObj.description.trim() === "")
            return setErrorMessage("Description is required.");
        if (!sliderObj.image)
            return setErrorMessage("Image is required.");

        try {
            setLoading(true);

            // Prepare form data for the API request
            const formData = new FormData();
            formData.append("title", sliderObj.title);
            formData.append("description", sliderObj.description);
            formData.append("image", sliderObj.image); // The file to be uploaded

            // Make the API request to insert the slider
            const response = await axios.post("https://website.smartbingogames.com/api/slider", formData, {
                headers: {
                    "Content-Type": "multipart/form-data", // Important for file uploads
                },
            });

            // Handle the success response
            if (response.data.message === "Slider created successfully") {
                // You can handle the success logic here, like redirecting or displaying a message
                window.location.href = '/app/sliders'; // Redirect to a page with sliders, for example
            } else {
                setErrorMessage("Failed to create slider.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setSliderObj({ ...sliderObj, [updateType]: value });
    };

    return (
        <div className="min-h-screen bg-base-200 flex items-center">
            <div className="card mx-auto w-full max-w-5xl shadow-xl">
                <div className="grid md:grid-cols-2 grid-cols-1 bg-base-100 rounded-xl">
                    <div className="py-24 px-10">
                        <h2 className="text-2xl font-semibold mb-2 text-center">Insert Slider</h2>
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                {/* Title Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-gray-700">Title</label>
                                    <input
                                        type="text"
                                        value={sliderObj.title}
                                        onChange={(e) => updateFormValue({ updateType: "title", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                {/* Description Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea
                                        value={sliderObj.description}
                                        onChange={(e) => updateFormValue({ updateType: "description", value: e.target.value })}
                                        className="textarea textarea-bordered w-full"
                                    ></textarea>
                                </div>

                                {/* Image Input */}
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-gray-700">Image</label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => updateFormValue({ updateType: "image", value: e.target.files[0] })}
                                        className="file-input file-input-bordered w-full"
                                    />
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Slider
                            </button>

                            {/* Link to another page (e.g., Sliders List) */}
                            <div className="text-center mt-4">
                                <Link to="/app/sliders">
                                    <span className="inline-block hover:text-primary hover:underline hover:cursor-pointer transition duration-200">
                                        View Sliders
                                    </span>
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SliderInsert;
