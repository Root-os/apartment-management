import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

const AddResourceForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: "",
    type: "",
    url: null,
    description: "",
  });

  // State for managing the loading state and errors
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  
  // State to control modal visibility
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState(""); 
  const [modalMessageType, setModalMessageType] = useState(null);

  // State to manage the file preview URL
  const [filePreview, setFilePreview] = useState(null);

  // Handle input changes for text fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle file selection or URL entry
  const handleUrlChange = (e) => {
    const value = e.target.value;
    const file = e.target.files ? e.target.files[0] : null;

    // If a file is selected, use that. Otherwise, treat the input as a URL.
    if (file) {
      setFormData({
        ...formData,
        url: file,
      });
      setFilePreview(URL.createObjectURL(file)); // Create a preview for the file
    } else if (value) {
      setFormData({
        ...formData,
        url: value,
      });
      setFilePreview(value); // If it's a URL, display it directly
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.type || !formData.url || !formData.description) {
      setError("Please fill all fields.");
      return;
    }

    setError(null);
    setSuccessMessage(null);
    setLoading(true); // Start loading

    const form = new FormData();
    form.append("title", formData.title);
    form.append("type", formData.type);
    form.append("description", formData.description);

    // If URL is a file, append it as a file, else append it as a string URL.
    if (typeof formData.url === "string") {
      form.append("url", formData.url); // Append as a string URL
    } else if (formData.url) {
      form.append("url", formData.url); // Append as a file
    }

    try {
      await axios.post(
        "https://website.smartbingogames.com/api/resource",
        form,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      setSuccessMessage("Resource added successfully!");
      setModalMessage("Resource added successfully!");
      setModalMessageType("success");
      setFormData({
        title: "",
        type: "",
        url: null,
        description: "",
      });

      setTimeout(() => {
        navigate('/ResourceList'); 
      }, 2000);
    } catch (error) {
      setError("An error occurred while adding the resource.");
      setModalMessage("An error occurred while adding the resource.");
      setModalMessageType("error");
    } finally {
      setLoading(false); // Stop loading
      setIsModalOpen(true); // Open the modal to show the message
    }
  };

  // Handle modal close
  const handleModalClose = () => {
    setIsModalOpen(false); // Close the modal
  };

  // Function to render media previews based on file type
  const renderFilePreview = () => {
    if (!formData.url) return null;

    if (typeof formData.url === "string") {
      // If the URL is a string, just display the link or load it in the browser
      return (
        <div className="mt-4">
          <a href={formData.url} target="_blank" rel="noopener noreferrer" className="text-blue-500">
            Open URL
          </a>
        </div>
      );
    }

    // If it's a file, check the type and render accordingly
    const file = formData.url;
    if (file.type.startsWith("image")) {
      return <img src={filePreview} alt="Preview" className="mt-4 max-w-full h-auto" />;
    } else if (file.type.startsWith("video")) {
      return <video controls src={filePreview} className="mt-4 max-w-full h-auto" />;
    } else if (file.type === "application/pdf") {
      return <iframe src={filePreview} className="mt-4 w-full h-96" title="PDF Preview" />;
    }

    return null;
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md ">
      <h1 className="text-2xl font-semibold mb-4">Add a Resource</h1>

      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-4 ">
          <label htmlFor="title" className="block text-sm font-medium text-gray-700">
            Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          />
        </div>

        <div className="mb-4">
          <label htmlFor="type" className="block text-sm font-medium text-gray-700">
            Type
          </label>
          <input
            type="text"
            id="type"
            name="type"
            value={formData.type}
            onChange={handleInputChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          />
        </div>

        <div className="mb-4">
          <label htmlFor="url" className="block text-sm font-medium text-gray-700">
            Choose File
          </label>
          <input
            type="file"
            id="url"
            name="url"
            accept="image/*,video/*,application/pdf" // Allows images, videos, and PDFs
            onChange={handleUrlChange}
            className="mt-1 block w-full text-sm text-gray-700 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            rows={4}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          ></textarea>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className={`w-full p-2 rounded-md text-white ${loading ? "bg-gray-400" : "bg-blue-500 hover:bg-blue-600"}`}
            disabled={loading}
          >
           {loading ? 'Submitting..' : 'Submit'}
          </button>
        </div>
      </form>

      {/* Display the file preview */}
      {renderFilePreview()}

      
    </div>
  );
};

export default AddResourceForm;
