import React, { useEffect, useState } from "react";
import axios from "axios";

const ResourcesPage = () => {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedResource, setSelectedResource] = useState(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchResources();
  }, []);

  const fetchResources = async () => {
    try {
      const response = await axios.get("https://website.smartbingogames.com/api/resource");
      setResources(response.data);
    } catch (err) {
      setError("An error occurred while fetching resources.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://website.smartbingogames.com/api/resource/${id}`);
      setResources(resources.filter((resource) => resource.id !== id));
      setIsDeleteModalOpen(false);
      setSuccessMessage("Resource deleted successfully!");
    } catch (err) {
      setError("An error occurred while deleting the resource.");
    }
  };

  const handleUpdate = async () => {
    if (selectedResource) {
      const updatedData = {
        title: selectedResource.title,
        type: selectedResource.type,
        description: selectedResource.description,
        url: selectedResource.url,
      };

      try {
        const response = await axios.put(
          `https://website.smartbingogames.com/api/resource/${selectedResource.id}`,
          updatedData
        );
        setResources(
          resources.map((resource) =>
            resource.id === selectedResource.id ? { ...resource, ...response.data.resource } : resource
          )
        );
        setIsUpdateModalOpen(false);
        setSuccessMessage("Resource updated successfully!");
      } catch (err) {
        setError("An error occurred while updating the resource.");
      }
    }
  };

  const filteredResources = resources.filter((resource) =>
    resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    resource.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const indexOfLastResource = currentPage * rowsPerPage;
  const indexOfFirstResource = indexOfLastResource - rowsPerPage;
  const currentResources = filteredResources.slice(indexOfFirstResource, indexOfLastResource);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  const handlePrev = () => currentPage > 1 && setCurrentPage(currentPage - 1);
  const handleNext = () => currentPage < Math.ceil(filteredResources.length / rowsPerPage) && setCurrentPage(currentPage + 1);

  const renderPreview = (url, type) => {
    const fileUrl = url;

    if (type.startsWith("image")) {
      return <img src={fileUrl} alt="Resource Preview" className="max-w-full h-auto" />;
    }
    if (type.startsWith("video")) {
      return <video controls src={fileUrl} className="max-w-full h-auto" />;
    }
    if (type === "application/pdf") {
      return <iframe src={fileUrl} className="w-full h-96" title="PDF Preview" />;
    }
    if (type === "application/msword" || type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
      return <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500">Download Word Document</a>;
    }

    return <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500">View Resource</a>;
  };

  return (
    <div className="overflow-x-auto">
      <h2 className="text-2xl font-semibold text-center mb-4">Resource List</h2>
        <>
          <div className="mb-4 flex justify-between items-center">
            <input
              type="text"
              className="p-2 border rounded-md w-1/2"
              placeholder="Search by Title or Description"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full table-auto border-collapse border border-gray-200">
              <thead>
                <tr>
                  <th className="px-4 py-2 border-b border-r">Title</th>
                  <th className="px-4 py-2 border-b border-r">Type</th>
                  <th className="px-4 py-2 border-b border-r">URL</th>
                  <th className="px-4 py-2 border-b border-r">Description</th>
                  <th className="px-4 py-2 border-b">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentResources.map((resource) => (
                  <tr key={resource.id}>
                    <td className="px-4 py-2 border-b border-r">{resource.title}</td>
                    <td className="px-4 py-2 border-b border-r">{resource.type}</td>
                    <td className="px-4 py-2 border-b border-r">
                      {renderPreview(resource.url, resource.type)}
                    </td>
                    <td className="px-4 py-2 border-b border-r">{resource.description}</td>
                    <td className="px-4 py-2 border-b flex space-x-2">
                      <button
                        onClick={() => {
                          setSelectedResource(resource);
                          setIsUpdateModalOpen(true);
                        }}
                        className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
                      >
                        Update
                      </button>
                      <button
                        onClick={() => {
                          setSelectedResource(resource);
                          setIsDeleteModalOpen(true);
                        }}
                        className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-4">
            <select
              value={rowsPerPage}
              onChange={(e) => setRowsPerPage(Number(e.target.value))}
              className="p-2 border rounded-md"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={20}>20</option>
            </select>
            <div>
              <button onClick={handlePrev} disabled={currentPage === 1} className="px-4 py-2 bg-gray-300 rounded-md mr-2">Prev</button>
              <span>Page {currentPage}</span>
              <button onClick={handleNext} disabled={currentPage === Math.ceil(filteredResources.length / rowsPerPage)} className="px-4 py-2 bg-gray-300 rounded-md">Next</button>
            </div>
          </div>
        </>
      {isUpdateModalOpen && selectedResource && (
        <div className="fixed inset-0 flex justify-center items-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h3 className="text-xl font-semibold mb-4">Update Resource</h3>
            <form>
              <div className="mb-4">
                <label htmlFor="title" className="block text-gray-700">Title</label>
                <input
                  type="text"
                  id="title"
                  value={selectedResource.title}
                  onChange={(e) =>
                    setSelectedResource({ ...selectedResource, title: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </div>
              <div className="mb-4">
                <label htmlFor="type" className="block text-gray-700">Type</label>
                <input
                  type="text"
                  id="type"
                  value={selectedResource.type}
                  onChange={(e) =>
                    setSelectedResource({ ...selectedResource, type: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </div>
              <div className="mb-4">
                <label htmlFor="description" className="block text-gray-700">Description</label>
                <input
                  type="text"
                  id="description"
                  value={selectedResource.description}
                  onChange={(e) =>
                    setSelectedResource({ ...selectedResource, description: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsUpdateModalOpen(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleUpdate}
                  className="px-4 py-2 bg-blue-600 text-white rounded"
                >
                  Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isDeleteModalOpen && selectedResource && (
        <div className="fixed inset-0 flex justify-center items-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h3 className="text-l font-semibold mb-4">Are you sure you want to delete this resource?</h3>
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => selectedResource?.id && handleDelete(selectedResource.id)}
                className="px-4 py-2 bg-red-600 text-white rounded"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResourcesPage;
