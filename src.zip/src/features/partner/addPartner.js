import { useState } from 'react';
import axios from 'axios';
import ErrorText from '../../components/Typography/ErrorText';
import TitleCard from '../../components/Cards/TitleCard'

function PartnerInsert() {
    const INITIAL_PARTNER_OBJ = {
        name: "",
        partnershipType: "",
        logo: null,
    };

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [partnerObj, setPartnerObj] = useState(INITIAL_PARTNER_OBJ);

    const submitForm = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        // Validation for empty fields
        if (partnerObj.name.trim() === "")
            return setErrorMessage("Partner name is required.");
        if (partnerObj.partnershipType.trim() === "")
            return setErrorMessage("Partnership type is required.");
        if (!partnerObj.logo)
            return setErrorMessage("Logo is required.");

        try {
            setLoading(true);

            // Prepare form data for the API request
            const formData = new FormData();
            formData.append("name", partnerObj.name);
            formData.append("partnershipType", partnerObj.partnershipType);
            formData.append("logoUrl", partnerObj.logo); // Assuming the logo is a file

            // Make the API request to insert the partner
            const response = await axios.post("https://website.smartbingogames.com/api/partner", formData);

            if (response.data.message === "Partner created successfully") {
                window.location.href = '/app/partner-view';  // Redirect to the partner view
            } else {
                setErrorMessage("Failed to create partner.");
            }
        } catch (error) {
            setErrorMessage("An error occurred while submitting the form.");
        } finally {
            setLoading(false);
        }
    };

    const updateFormValue = ({ updateType, value }) => {
        setErrorMessage("");
        setPartnerObj({ ...partnerObj, [updateType]: value });
    };

    return (
        <>
          <TitleCard title="FAQS" topMargin=""mt-6>
                        <form onSubmit={submitForm}>
                            <div className="mb-4">
                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Partner Name</label>
                                    <input
                                        type="text"
                                        value={partnerObj.name}
                                        onChange={(e) => updateFormValue({ updateType: "name", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Partnership Type</label>
                                    <input
                                        type="text"
                                        value={partnerObj.partnershipType}
                                        onChange={(e) => updateFormValue({ updateType: "partnershipType", value: e.target.value })}
                                        className="input input-bordered w-full"
                                    />
                                </div>

                                <div className="mt-4">
                                    <label className="block text-sm font-medium text-white-700">Logo</label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => updateFormValue({ updateType: "logo", value: e.target.files[0] })}
                                        className="file-input file-input-bordered w-full"
                                    />
                                </div>
                            </div>

                            {/* Error Message */}
                            <ErrorText styleClass="mt-8">{errorMessage}</ErrorText>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className={"btn mt-2 w-full btn-primary" + (loading ? " loading" : "")}
                                disabled={loading}
                            >
                                Insert Partner
                            </button>
                        </form>
                    </TitleCard>
                  </>
    );
}

export default PartnerInsert;
