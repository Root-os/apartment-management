import React, { useEffect, useState } from "react";
import axios from "axios";
import TitleCard from '../../components/Cards/TitleCard'

// Modal Component for displaying success/error messages
const Modal = ({ isOpen, message, messageType, closeModal }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-md shadow-lg max-w-lg w-full">
        <h3 className="text-lg mb-4 text-black">{messageType === 'success' ? 'Success' : 'Error'}</h3>
        <p className="mb-4">{message}</p>
        <div className="flex justify-end space-x-4">
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
            onClick={closeModal}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

const PartnerPage = () => {
  const [loading, setLoading] = useState(true);
  const [partners, setPartners] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [totalRows, setTotalRows] = useState(0);

  const [editingPartner, setEditingPartner] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(null);
  const [viewDetails, setViewDetails] = useState(null);

  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalMessageType, setModalMessageType] = useState(null);

  const [updatedName, setUpdatedName] = useState("");
  const [updatedLogo, setUpdatedLogo] = useState(null);
  const [updatedPartnershipType, setUpdatedPartnershipType] = useState("");

  useEffect(() => {
    fetchPartnersData();
  }, []);

  const fetchPartnersData = async () => {
    try {
      const response = await axios.get("https://website.smartbingogames.com/api/partner");
      setPartners(response.data);
      setTotalRows(response.data.length);
    } catch (error) {
      console.error("Error fetching partners:", error);
    }
  };

  const filteredPartners = partners.filter((partner) =>
    partner.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const indexOfLastPartner = currentPage * rowsPerPage;
  const indexOfFirstPartner = indexOfLastPartner - rowsPerPage;
  const currentPartners = filteredPartners.slice(
    indexOfFirstPartner,
    indexOfLastPartner
  );

  const handleDelete = (id) => {
    setDeleteConfirmation(id);
  };

  const confirmDelete = () => {
    if (deleteConfirmation !== null) {
      axios
        .delete(`https://website.smartbingogames.com/api/partner/${deleteConfirmation}`)
        .then(() => {
          setPartners((prevPartners) =>
            prevPartners.filter((partner) => partner.id !== deleteConfirmation)
          );
          setDeleteConfirmation(null);
          setModalMessage("Partner deleted successfully!");
          setModalMessageType('success');
          setModalIsOpen(true);
        })
        .catch(() => {
          setModalMessage("Failed to delete partner!");
          setModalMessageType('error');
          setModalIsOpen(true);
        });
    }
  };

  const cancelDelete = () => {
    setDeleteConfirmation(null);
  };

  const handleUpdate = (partner) => {
    setEditingPartner(partner);
    setUpdatedName(partner.name);
    setUpdatedPartnershipType(partner.partnershipType);
    setUpdatedLogo(null);
  };

  const handleUpdateSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', updatedName);
    formData.append('partnershipType', updatedPartnershipType);
    if (updatedLogo) formData.append('logoUrl', updatedLogo);

    if (editingPartner) {
      axios
        .put(`https://website.smartbingogames.com/api/partner/${editingPartner.id}`, formData)
        .then((response) => {
          const updatedPartner = response.data.partner;
          setPartners((prevPartners) =>
            prevPartners.map((partner) =>
              partner.id === updatedPartner.id ? updatedPartner : partner
            )
          );
          setModalMessage("Partner updated successfully!");
          setModalMessageType('success');
          setModalIsOpen(true);
          setEditingPartner(null);
          fetchPartnersData();
        })
        .catch(() => {
          setModalMessage("Failed to update partner!");
          setModalMessageType('error');
          setModalIsOpen(true);
        });
    }
  };

  const openDetailsModal = (partner) => {
    setViewDetails(partner);
  };

  const closeDetailsModal = () => {
    setViewDetails(null);
  };

  return (
    <><TitleCard title="Partners" topMargin=""mt-6>
      
      <div className="flex justify-between mb-4">
        <input
          type="text"
          className="input input-bordered w-full"
          placeholder="Search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <table className="table w-full">
        <thead>
          <tr>
            <th >Partner Name</th>
            <th >Logo</th>
            <th >Partnership Type</th>
            <th >Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentPartners.map((partner) => (
            <tr key={partner.id}>
              <td >{partner.name}</td>
              <td >
                <img src={partner.logoUrl} alt={partner.name} className="w-16" />
              </td>
              <td >{partner.partnershipType}</td>
              <td className=" flex space-x-2">
                <div className="dropdown">
                  <button className="bg-gray-500 text-white px-4 py-2 rounded-md">
                    Actions
                  </button>
                  <div className="dropdown-content bg-white shadow-lg border rounded-md w-40">
                    <button
                      className="block text-black w-full px-4 py-2"
                      onClick={() => handleUpdate(partner)}
                    >
                      Edit
                    </button>
                    <button
                      className="block text-red-500 w-full px-4 py-2"
                      onClick={() => handleDelete(partner.id)}
                    >
                      Delete
                    </button>
                    <button
                      className="block text-blue-500 w-full px-4 py-2"
                      onClick={() => openDetailsModal(partner)}
                    >
                      View Details
                    </button>
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Update Partner Modal */}
      {editingPartner && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-base-300 p-6 rounded-md shadow-lg max-w-lg w-full">
            <h3 className="text-lg mb-4">Update Partner</h3>
            <form onSubmit={handleUpdateSubmit}>
              <div className="mb-4">
                <label htmlFor="name">Partner Name</label>
                <input
                  type="text"
                  id="name"
                  className="input input-bordered w-full"
                  value={updatedName}
                  onChange={(e) => setUpdatedName(e.target.value)}
                />
              </div>
              <div className="mb-4">
                <label htmlFor="partnershipType">Partnership Type</label>
                <input
                  type="text"
                  id="partnershipType"
                  className="input input-bordered w-full"
                  value={updatedPartnershipType}
                  onChange={(e) => setUpdatedPartnershipType(e.target.value)}
                />
              </div>
              <div className="mb-4">
                <label htmlFor="logo">Logo</label>
                <input
                  type="file"
                  id="logo"
                  className="input input-bordered w-full"
                  onChange={(e) => setUpdatedLogo(e.target.files[0])}
                />
              </div>
              <div className="flex justify-end space-x-4">
                <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded-md">
                  Save Changes
                </button>
                <button
                  type="button"
                  className=" text-white-800 px-4 py-2 rounded-md"
                  onClick={() => setEditingPartner(null)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Details Modal */}
      {viewDetails && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-md shadow-lg max-w-lg w-full">
            <h3 className="text-lg mb-4">Partner Details</h3>
            <p><strong>Name:</strong> {viewDetails.name}</p>
            <p><strong>Partnership Type:</strong> {viewDetails.partnershipType}</p>
            <div className="flex justify-end space-x-4">
              <button
                className="bg-blue-500 text-white px-4 py-2 rounded-md"
                onClick={closeDetailsModal}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for success/error messages */}
      <Modal
        isOpen={modalIsOpen}
        message={modalMessage}
        messageType={modalMessageType}
        closeModal={() => setModalIsOpen(false)}
      />
  </TitleCard></>
  );
};

export default PartnerPage;
