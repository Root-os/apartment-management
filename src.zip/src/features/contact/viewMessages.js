import { useState, useEffect } from "react";
import axios from "axios";
import moment from "moment";
import TitleCard from "../../components/Cards/TitleCard";
import SearchBar from "../../components/Input/SearchBar";
import { FunnelIcon, XMarkIcon } from '@heroicons/react/24/outline';

// Modal components for Delete Confirmation
const DeleteConfirmationModal = ({ isOpen, contact, deleteContact, closeModal }) => {
  return (
    isOpen && (
      <div className="modal modal-open">
        <div className="modal-box">
          <h2>Are you sure you want to delete this contact?</h2>
          <p><strong>Name:</strong> {contact.name}</p>
          <p><strong>Email:</strong> {contact.email}</p>
          <div className="modal-action">
            <button className="btn" onClick={() => deleteContact(contact.id)}>
              Confirm
            </button>
            <button className="btn btn-ghost" onClick={closeModal}>
              Cancel
            </button>
          </div>
        </div>
      </div>
    )
  );
};

// TopSideButtons Component for Search and Filters
const TopSideButtons = ({ applySearch, removeFilter }) => {
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    if (searchText === "") {
      removeFilter();
    } else {
      applySearch(searchText);
    }
  }, [searchText]);

  return (
    <div className="inline-block float-right">
      <SearchBar searchText={searchText} styleClass="mr-4" setSearchText={setSearchText} />
    </div>
  );
};

function ContactPage() {
  const [contacts, setContacts] = useState([]);
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [sortOrder, setSortOrder] = useState("asc");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    axios
      .get("https://website.smartbingogames.com/api/contact")
      .then((response) => {
        setContacts(response.data);
        setFilteredContacts(response.data);
      })
      .catch((error) => {
        console.error("Error fetching contacts:", error);
      });
  }, []);

  const applySearch = (value) => {
    setSearchText(value);
    const filtered = contacts.filter((contact) =>
      contact.name.toLowerCase().includes(value.toLowerCase()) ||
      contact.email.toLowerCase().includes(value.toLowerCase()) ||
      contact.subject.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredContacts(filtered);
  };

  const removeFilter = () => {
    setSearchText("");
    setFilteredContacts(contacts);
  };

  const handleSort = (column) => {
    const sortedContacts = [...filteredContacts];
    const order = sortOrder === "asc" ? "desc" : "asc";
    sortedContacts.sort((a, b) => {
      if (a[column] < b[column]) return order === "asc" ? -1 : 1;
      if (a[column] > b[column]) return order === "asc" ? 1 : -1;
      return 0;
    });

    setFilteredContacts(sortedContacts);
    setSortOrder(order);
  };

  const changePage = (newPage) => {
    if (newPage >= 1 && newPage <= Math.ceil(filteredContacts.length / rowsPerPage)) {
      setPage(newPage);
    }
  };

  const startIndex = (page - 1) * rowsPerPage;
  const endIndex = startIndex + rowsPerPage;

  const openDetailsModal = (contact) => {
    setSelectedContact(contact);
    setDetailsModalOpen(true);
  };

  const closeDetailsModal = () => setDetailsModalOpen(false);

  const openDeleteModal = (contact) => {
    setSelectedContact(contact);
    setDeleteModalOpen(true);
  };

  const closeDeleteModal = () => setDeleteModalOpen(false);

  const deleteContact = (id) => {
    axios
      .delete(`https://website.smartbingogames.com/api/contact/${id}`)
      .then(() => {
        setContacts((prevContacts) =>
          prevContacts.filter((contact) => contact.id !== id)
        );
        closeDeleteModal();
      })
      .catch((error) => console.error("Error deleting contact:", error));
  };

  return (
    <>
      <TitleCard title="Messages" topMargin="mt-2" TopSideButtons={<TopSideButtons applySearch={applySearch} removeFilter={removeFilter} />}>
        <div className="overflow-x-auto w-full">
          <table className="table w-full">
            <thead>
              <tr>
                <th onClick={() => handleSort("name")} className="cursor-pointer">Name</th>
                <th onClick={() => handleSort("email")} className="cursor-pointer">Email</th>
                <th onClick={() => handleSort("subject")} className="cursor-pointer">Subject</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredContacts.slice(startIndex, endIndex).map((contact) => (
                <tr key={contact.id}>
                  <td>{contact.name}</td>
                  <td>{contact.email}</td>
                  <td>{contact.subject}</td>
                  <td>
                    <button className="btn btn-sm btn-danger bg-red-500" onClick={() => openDeleteModal(contact)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center mt-4">
          <div className="flex items-center">
            <select className="ml-2 select select-bordered w-10" value={rowsPerPage} onChange={(e) => setRowsPerPage(Number(e.target.value))}>
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="20">20</option>
            </select>
          </div>

          <div className="flex items-center">
            <button className="btn btn-sm btn-ghost" onClick={() => changePage(page - 1)} disabled={page === 1}>
              Prev
            </button>
            <span className="mx-2">{page}</span>
            <button
              className="btn btn-sm btn-ghost"
              onClick={() => changePage(page + 1)}
              disabled={page === Math.ceil(filteredContacts.length / rowsPerPage)}
            >
              Next
            </button>
          </div>
        </div>
      </TitleCard>

      {/* Modals */}
      {/* <ContactDetailsModal contact={selectedContact} isOpen={detailsModalOpen} closeModal={closeDetailsModal} /> */}
      <DeleteConfirmationModal 
        isOpen={deleteModalOpen} 
        contact={selectedContact} 
        deleteContact={deleteContact} 
        closeModal={closeDeleteModal} 
      />
    </>
  );
}

export default ContactPage;
